import React, { useState, useEffect } from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { StatusBar } from 'expo-status-bar';
import { View, Text } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

// Import screens
import SplashScreen from './src/screens/SplashScreen';
import OnboardingScreen from './src/screens/OnboardingScreen';
import LoginScreen from './src/screens/auth/LoginScreen';
import RegisterScreen from './src/screens/auth/RegisterScreen';
import VerificationScreen from './src/screens/auth/VerificationScreen';

// Passenger Screens
import PassengerHomeScreen from './src/screens/passenger/HomeScreen';
import SearchRidesScreen from './src/screens/passenger/SearchRidesScreen';
import RideDetailsScreen from './src/screens/passenger/RideDetailsScreen';
import BookingScreen from './src/screens/passenger/BookingScreen';
import PaymentScreen from './src/screens/passenger/PaymentScreen';
import BookingHistoryScreen from './src/screens/passenger/BookingHistoryScreen';
import BookingDetailsScreen from './src/screens/passenger/BookingDetailsScreen';
import BookingConfirmationScreen from './src/screens/passenger/BookingConfirmationScreen';
import TicketScreen from './src/screens/passenger/TicketScreen';
import PassengerProfileScreen from './src/screens/passenger/ProfileScreen';
import CheckInScreen from './src/screens/passenger/CheckInScreen';

// Driver Screens
import DriverHomeScreen from './src/screens/driver/HomeScreen';
import CreateRideScreen from './src/screens/driver/CreateRideScreen';
import ManageRidesScreen from './src/screens/driver/ManageRidesScreen';
import DriverProfileScreen from './src/screens/driver/ProfileScreen';
import TripDetailsScreen from './src/screens/driver/TripDetailsScreen';

// Navigation
const Stack = createStackNavigator();
const Tab = createBottomTabNavigator();

// Passenger Tab Navigator
function PassengerTabNavigator() {
  return (
    <Tab.Navigator
      screenOptions={{
        tabBarActiveTintColor: '#008000',
        tabBarInactiveTintColor: 'gray',
        headerShown: false,
      }}
    >
      <Tab.Screen 
        name="Home" 
        component={PassengerHomeScreen} 
        options={{
          tabBarLabel: 'Home',
        }}
      />
      <Tab.Screen 
        name="Search" 
        component={SearchRidesScreen} 
        options={{
          tabBarLabel: 'Search',
        }}
      />
      <Tab.Screen 
        name="BookingHistory" 
        component={BookingHistoryScreen} 
        options={{
          tabBarLabel: 'My Bookings',
        }}
      />
      <Tab.Screen 
        name="Profile" 
        component={PassengerProfileScreen} 
        options={{
          tabBarLabel: 'Profile',
        }}
      />
    </Tab.Navigator>
  );
}

// Driver Tab Navigator
function DriverTabNavigator() {
  return (
    <Tab.Navigator
      screenOptions={{
        tabBarActiveTintColor: '#008000',
        tabBarInactiveTintColor: 'gray',
        headerShown: false,
      }}
    >
      <Tab.Screen 
        name="Home" 
        component={DriverHomeScreen} 
        options={{
          tabBarLabel: 'Home',
        }}
      />
      <Tab.Screen 
        name="CreateRide" 
        component={CreateRideScreen} 
        options={{
          tabBarLabel: 'Create Ride',
        }}
      />
      <Tab.Screen 
        name="ManageRides" 
        component={ManageRidesScreen} 
        options={{
          tabBarLabel: 'Manage',
        }}
      />
      <Tab.Screen 
        name="Profile" 
        component={DriverProfileScreen} 
        options={{
          tabBarLabel: 'Profile',
        }}
      />
    </Tab.Navigator>
  );
}

export default function App() {
  const [isLoading, setIsLoading] = useState(true);
  const [isFirstLaunch, setIsFirstLaunch] = useState(null);
  const [userToken, setUserToken] = useState(null);
  const [userType, setUserType] = useState(null); // 'passenger' or 'driver'

  useEffect(() => {
    // Check if it's the first launch
    AsyncStorage.getItem('alreadyLaunched').then(value => {
      if (value === null) {
        AsyncStorage.setItem('alreadyLaunched', 'true');
        setIsFirstLaunch(true);
      } else {
        setIsFirstLaunch(false);
      }
    });

    // Check if user is logged in
    AsyncStorage.getItem('userToken').then(token => {
      setUserToken(token);
    });

    // Check user type
    AsyncStorage.getItem('userType').then(type => {
      setUserType(type);
    });

    // Simulate splash screen
    setTimeout(() => {
      setIsLoading(false);
    }, 2000);
  }, []);

  if (isLoading) {
    return <SplashScreen />;
  }

  return (
    <NavigationContainer>
      <StatusBar style="auto" />
      <Stack.Navigator screenOptions={{ headerShown: false }}>
        {isFirstLaunch && (
          <Stack.Screen name="Onboarding" component={OnboardingScreen} />
        )}
        {!userToken ? (
          <>
            <Stack.Screen name="Login" component={LoginScreen} />
            <Stack.Screen name="Register" component={RegisterScreen} />
            <Stack.Screen name="Verification" component={VerificationScreen} />
          </>
        ) : userType === 'passenger' ? (
          <>
            <Stack.Screen name="PassengerMain" component={PassengerTabNavigator} />
            <Stack.Screen 
              name="RideDetails" 
              component={RideDetailsScreen} 
              options={{ headerShown: true, title: 'Ride Details' }}
            />
            <Stack.Screen 
              name="Booking" 
              component={BookingScreen} 
              options={{ headerShown: true, title: 'Book a Ride' }}
            />
            <Stack.Screen 
              name="Payment" 
              component={PaymentScreen} 
              options={{ headerShown: true, title: 'Payment' }}
            />
            <Stack.Screen 
              name="CheckIn" 
              component={CheckInScreen} 
              options={{ headerShown: true, title: 'Check In' }}
            />
            <Stack.Screen 
              name="BookingDetails" 
              component={BookingDetailsScreen} 
              options={{ headerShown: false }}
            />
            <Stack.Screen 
              name="BookingConfirmation" 
              component={BookingConfirmationScreen} 
              options={{ headerShown: false }}
            />
            <Stack.Screen 
              name="Ticket" 
              component={TicketScreen} 
              options={{ headerShown: true, title: 'Ticket' }}
            />
          </>
        ) : (
          <>
            <Stack.Screen name="DriverMain" component={DriverTabNavigator} />
            <Stack.Screen 
              name="TripDetails" 
              component={TripDetailsScreen} 
              options={{ headerShown: false }}
            />
          </>
        )}
      </Stack.Navigator>
    </NavigationContainer>
  );
}