# 9jaRide Mobile App

A mobile application for the Nigerian Transport system that connects passengers with the most suitable car for their journey.

## Features

### For Drivers
- Registration and verification
- Dashboard to post journey details (departure place, destination, date, time, available seats)
- Track booked seats and manage bookings
- View trip statistics and earnings
- Profile management with vehicle information
- Real-time notifications for new bookings

### For Passengers
- Registration and verification
- Search for suitable rides based on location, date, and preferences
- View detailed car and driver information
- Book seats with interactive seat selection
- Make secure payments via Paystack (card and bank transfer)
- Track booking history and upcoming trips
- Check-in functionality after boarding
- Share booking details with others

## Technology Stack
- React Native / Expo
- React Navigation (Stack and Tab navigators)
- AsyncStorage for local data persistence
- Paystack API for payment processing
- Expo Status Bar for UI enhancements

## Installation

1. Clone the repository:
```
git clone https://github.com/yourusername/9jaRide.git
cd 9jaRide
```

2. Install dependencies:
```
npm install
```

3. Start the development server:
```
npm start
```

4. Run on a device or emulator:
```
npm run android
# or
npm run ios
```

## Project Structure

```
9jaRide/
├── assets/            # App icons and images
├── src/
│   ├── components/    # Reusable UI components
│   ├── constants/     # App constants and configuration
│   ├── screens/       # Screen components
│   │   ├── auth/      # Authentication screens
│   │   ├── driver/    # Driver-specific screens
│   │   └── passenger/ # Passenger-specific screens
│   ├── services/      # API and service integrations
│   └── utils/         # Utility functions
├── App.js             # Main application component
└── package.json       # Project dependencies
```

## Usage

### For Passengers
1. Register or log in to your account
2. Search for rides based on your destination and travel date
3. Select a ride and choose your preferred seat(s)
4. Complete payment using Paystack
5. View your booking details and check in when boarding

### For Drivers
1. Register or log in as a driver
2. Create new trips with details like route, date, time, and available seats
3. Manage bookings and check in passengers
4. Track earnings and trip statistics

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## License

This project is licensed under the MIT License - see the LICENSE file for details.