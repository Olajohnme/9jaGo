import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  Image,
  Alert,
  RefreshControl,
} from 'react-native';
import { StatusBar } from 'expo-status-bar';
import AsyncStorage from '@react-native-async-storage/async-storage';

const BookingHistoryScreen = ({ navigation }) => {
  const [bookings, setBookings] = useState([]);
  const [activeTab, setActiveTab] = useState('upcoming');
  const [refreshing, setRefreshing] = useState(false);
  const [userName, setUserName] = useState('');

  useEffect(() => {
    loadUserData();
    loadBookings();
  }, []);

  const loadUserData = async () => {
    try {
      const userData = await AsyncStorage.getItem('userData');
      if (userData) {
        const parsedData = JSON.parse(userData);
        setUserName(parsedData.fullName || 'User');
      }
    } catch (error) {
      console.log('Error loading user data:', error);
    }
  };

  const loadBookings = async () => {
    try {
      setRefreshing(true);
      // In a real app, this would be fetched from a backend API
      const bookingsData = await AsyncStorage.getItem('userBookings');
      
      if (bookingsData) {
        setBookings(JSON.parse(bookingsData));
      } else {
        // Create mock bookings for demo
        const mockBookings = generateMockBookings();
        setBookings(mockBookings);
        await AsyncStorage.setItem('userBookings', JSON.stringify(mockBookings));
      }
    } catch (error) {
      console.log('Error loading bookings:', error);
      Alert.alert('Error', 'Failed to load bookings. Please try again.');
    } finally {
      setRefreshing(false);
    }
  };

  const generateMockBookings = () => {
    const currentDate = new Date();
    const mockBookings = [];
    
    // Generate 5 upcoming bookings
    for (let i = 0; i < 5; i++) {
      const departureDate = new Date(currentDate);
      departureDate.setDate(departureDate.getDate() + i + 1);
      
      mockBookings.push({
        id: `booking_upcoming_${i + 1}`,
        tripId: `trip_${i + 1}`,
        from: getRandomCity(),
        to: getRandomCity(),
        departureDate: departureDate.toISOString(),
        departureTime: `${Math.floor(Math.random() * 12) + 1}:${Math.random() > 0.5 ? '30' : '00'} ${Math.random() > 0.5 ? 'AM' : 'PM'}`,
        price: Math.floor(Math.random() * 10000) + 2000,
        seats: [Math.floor(Math.random() * 20) + 1],
        status: 'confirmed',
        driverName: getRandomName(),
        carModel: getRandomCar(),
        carColor: getRandomColor(),
        bookingDate: new Date(currentDate.getTime() - Math.random() * 86400000 * 5).toISOString(),
        paymentMethod: Math.random() > 0.5 ? 'Card' : 'Bank Transfer',
        bookingId: generateBookingId(),
      });
    }
    
    // Generate 5 past bookings
    for (let i = 0; i < 5; i++) {
      const departureDate = new Date(currentDate);
      departureDate.setDate(departureDate.getDate() - i - 1);
      
      mockBookings.push({
        id: `booking_past_${i + 1}`,
        tripId: `trip_past_${i + 1}`,
        from: getRandomCity(),
        to: getRandomCity(),
        departureDate: departureDate.toISOString(),
        departureTime: `${Math.floor(Math.random() * 12) + 1}:${Math.random() > 0.5 ? '30' : '00'} ${Math.random() > 0.5 ? 'AM' : 'PM'}`,
        price: Math.floor(Math.random() * 10000) + 2000,
        seats: [Math.floor(Math.random() * 20) + 1],
        status: Math.random() > 0.8 ? 'cancelled' : 'completed',
        driverName: getRandomName(),
        carModel: getRandomCar(),
        carColor: getRandomColor(),
        bookingDate: new Date(departureDate.getTime() - Math.random() * 86400000 * 2).toISOString(),
        paymentMethod: Math.random() > 0.5 ? 'Card' : 'Bank Transfer',
        bookingId: generateBookingId(),
      });
    }
    
    return mockBookings;
  };
  
  const getRandomCity = () => {
    const cities = ['Lagos', 'Abuja', 'Port Harcourt', 'Ibadan', 'Kano', 'Enugu', 'Calabar', 'Benin City', 'Owerri', 'Kaduna'];
    return cities[Math.floor(Math.random() * cities.length)];
  };
  
  const getRandomName = () => {
    const firstNames = ['John', 'Mary', 'David', 'Sarah', 'Michael', 'Jennifer', 'Chioma', 'Emeka', 'Ngozi', 'Oluwaseun'];
    const lastNames = ['Smith', 'Johnson', 'Williams', 'Brown', 'Jones', 'Okonkwo', 'Adeyemi', 'Okafor', 'Nwachukwu', 'Eze'];
    
    return `${firstNames[Math.floor(Math.random() * firstNames.length)]} ${lastNames[Math.floor(Math.random() * lastNames.length)]}`;
  };
  
  const getRandomCar = () => {
    const cars = ['Toyota Camry', 'Honda Accord', 'Toyota Corolla', 'Kia Rio', 'Hyundai Elantra', 'Mazda 3', 'Honda Civic', 'Toyota Sienna', 'Ford Focus', 'Nissan Altima'];
    return cars[Math.floor(Math.random() * cars.length)];
  };
  
  const getRandomColor = () => {
    const colors = ['Black', 'White', 'Silver', 'Gray', 'Red', 'Blue', 'Green', 'Brown', 'Gold', 'Navy'];
    return colors[Math.floor(Math.random() * colors.length)];
  };
  
  const generateBookingId = () => {
    return `9JR${Math.floor(Math.random() * 10000).toString().padStart(4, '0')}`;
  };

  const onRefresh = () => {
    loadBookings();
  };

  const handleCancelBooking = (bookingId) => {
    Alert.alert(
      'Cancel Booking',
      'Are you sure you want to cancel this booking?',
      [
        {
          text: 'No',
          style: 'cancel',
        },
        {
          text: 'Yes',
          onPress: async () => {
            try {
              // Update booking status
              const updatedBookings = bookings.map(booking => {
                if (booking.id === bookingId) {
                  return { ...booking, status: 'cancelled' };
                }
                return booking;
              });
              
              setBookings(updatedBookings);
              await AsyncStorage.setItem('userBookings', JSON.stringify(updatedBookings));
              
              Alert.alert('Success', 'Booking has been cancelled successfully!');
            } catch (error) {
              console.log('Error cancelling booking:', error);
              Alert.alert('Error', 'Failed to cancel booking. Please try again.');
            }
          },
        },
      ],
      { cancelable: false }
    );
  };

  const handleViewBooking = (booking) => {
    navigation.navigate('BookingDetails', { booking });
  };

  const filteredBookings = bookings.filter(booking => {
    const bookingDate = new Date(booking.departureDate);
    const currentDate = new Date();
    
    if (activeTab === 'upcoming') {
      return bookingDate >= currentDate && booking.status !== 'cancelled';
    } else {
      return bookingDate < currentDate || booking.status === 'cancelled';
    }
  });

  const renderBookingItem = ({ item }) => {
    const departureDate = new Date(item.departureDate);
    const formattedDate = departureDate.toLocaleDateString('en-NG', {
      weekday: 'short',
      day: 'numeric',
      month: 'short',
      year: 'numeric',
    });
    
    const isUpcoming = new Date(item.departureDate) >= new Date() && item.status !== 'cancelled';
    const canCancel = isUpcoming && activeTab === 'upcoming';
    
    return (
      <TouchableOpacity
        style={styles.bookingCard}
        onPress={() => handleViewBooking(item)}
      >
        <View style={styles.bookingHeader}>
          <View style={styles.locationContainer}>
            <Text style={styles.fromText}>{item.from}</Text>
            <View style={styles.arrowContainer}>
              <View style={styles.arrowLine} />
              <Text style={styles.arrowHead}>▶</Text>
            </View>
            <Text style={styles.toText}>{item.to}</Text>
          </View>
          
          <View style={[
            styles.statusBadge,
            item.status === 'confirmed' ? styles.confirmedBadge :
            item.status === 'completed' ? styles.completedBadge :
            styles.cancelledBadge
          ]}>
            <Text style={[
              styles.statusText,
              item.status === 'confirmed' ? styles.confirmedText :
              item.status === 'completed' ? styles.completedText :
              styles.cancelledText
            ]}>
              {item.status === 'confirmed' ? 'Confirmed' :
               item.status === 'completed' ? 'Completed' :
               'Cancelled'}
            </Text>
          </View>
        </View>
        
        <View style={styles.bookingDetails}>
          <View style={styles.detailRow}>
            <View style={styles.detailItem}>
              <Text style={styles.detailLabel}>Date</Text>
              <Text style={styles.detailValue}>{formattedDate}</Text>
            </View>
            
            <View style={styles.detailItem}>
              <Text style={styles.detailLabel}>Time</Text>
              <Text style={styles.detailValue}>{item.departureTime}</Text>
            </View>
            
            <View style={styles.detailItem}>
              <Text style={styles.detailLabel}>Seat</Text>
              <Text style={styles.detailValue}>{item.seats.join(', ')}</Text>
            </View>
          </View>
          
          <View style={styles.driverInfo}>
            <View style={styles.driverAvatar}>
              <Text style={styles.driverInitial}>{item.driverName.charAt(0)}</Text>
            </View>
            
            <View style={styles.driverDetails}>
              <Text style={styles.driverName}>{item.driverName}</Text>
              <Text style={styles.carDetails}>{item.carModel} • {item.carColor}</Text>
            </View>
          </View>
        </View>
        
        <View style={styles.bookingFooter}>
          <View style={styles.priceContainer}>
            <Text style={styles.priceLabel}>Price</Text>
            <Text style={styles.priceValue}>₦{item.price.toLocaleString()}</Text>
          </View>
          
          {canCancel && (
            <TouchableOpacity
              style={styles.cancelButton}
              onPress={() => handleCancelBooking(item.id)}
            >
              <Text style={styles.cancelButtonText}>Cancel</Text>
            </TouchableOpacity>
          )}
          
          <TouchableOpacity
            style={styles.viewButton}
            onPress={() => handleViewBooking(item)}
          >
            <Text style={styles.viewButtonText}>View</Text>
          </TouchableOpacity>
        </View>
      </TouchableOpacity>
    );
  };

  const renderEmptyList = () => (
    <View style={styles.emptyContainer}>
      <Text style={styles.emptyText}>
        {activeTab === 'upcoming' ? 'No upcoming bookings' : 'No past bookings'}
      </Text>
      <Text style={styles.emptySubtext}>
        {activeTab === 'upcoming' ? 'Your upcoming bookings will appear here' : 'Your past bookings will appear here'}
      </Text>
    </View>
  );

  return (
    <View style={styles.container}>
      <StatusBar style="light" />
      
      <View style={styles.header}>
        <Text style={styles.headerTitle}>My Bookings</Text>
      </View>
      
      <View style={styles.tabContainer}>
        <TouchableOpacity
          style={[styles.tab, activeTab === 'upcoming' && styles.activeTab]}
          onPress={() => setActiveTab('upcoming')}
        >
          <Text style={[styles.tabText, activeTab === 'upcoming' && styles.activeTabText]}>
            Upcoming
          </Text>
        </TouchableOpacity>
        
        <TouchableOpacity
          style={[styles.tab, activeTab === 'past' && styles.activeTab]}
          onPress={() => setActiveTab('past')}
        >
          <Text style={[styles.tabText, activeTab === 'past' && styles.activeTabText]}>
            Past
          </Text>
        </TouchableOpacity>
      </View>
      
      <FlatList
        data={filteredBookings}
        renderItem={renderBookingItem}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.bookingsList}
        showsVerticalScrollIndicator={false}
        ListEmptyComponent={renderEmptyList}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={onRefresh}
            colors={['#008000']}
            tintColor="#008000"
          />
        }
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F5F5',
  },
  header: {
    backgroundColor: '#008000',
    paddingTop: 50,
    paddingBottom: 15,
    paddingHorizontal: 20,
    alignItems: 'center',
  },
  headerTitle: {
    color: '#FFFFFF',
    fontSize: 20,
    fontWeight: 'bold',
  },
  tabContainer: {
    flexDirection: 'row',
    backgroundColor: '#FFFFFF',
    paddingVertical: 10,
    marginBottom: 10,
  },
  tab: {
    flex: 1,
    alignItems: 'center',
    paddingVertical: 10,
    borderBottomWidth: 2,
    borderBottomColor: 'transparent',
  },
  activeTab: {
    borderBottomColor: '#008000',
  },
  tabText: {
    fontSize: 16,
    fontWeight: '500',
    color: '#666666',
  },
  activeTabText: {
    color: '#008000',
    fontWeight: 'bold',
  },
  bookingsList: {
    padding: 15,
    paddingBottom: 30,
  },
  bookingCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 15,
    padding: 15,
    marginBottom: 15,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  bookingHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 15,
    borderBottomWidth: 1,
    borderBottomColor: '#F0F0F0',
    paddingBottom: 15,
  },
  locationContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  fromText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333333',
  },
  arrowContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginHorizontal: 10,
  },
  arrowLine: {
    height: 1,
    width: 30,
    backgroundColor: '#CCCCCC',
  },
  arrowHead: {
    color: '#CCCCCC',
    fontSize: 12,
  },
  toText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333333',
  },
  statusBadge: {
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 20,
  },
  confirmedBadge: {
    backgroundColor: '#E8F5E9',
  },
  completedBadge: {
    backgroundColor: '#E3F2FD',
  },
  cancelledBadge: {
    backgroundColor: '#FFEBEE',
  },
  statusText: {
    fontSize: 12,
    fontWeight: '500',
  },
  confirmedText: {
    color: '#008000',
  },
  completedText: {
    color: '#1976D2',
  },
  cancelledText: {
    color: '#D32F2F',
  },
  bookingDetails: {
    marginBottom: 15,
  },
  detailRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 15,
  },
  detailItem: {
    alignItems: 'center',
  },
  detailLabel: {
    fontSize: 12,
    color: '#999999',
    marginBottom: 5,
  },
  detailValue: {
    fontSize: 14,
    fontWeight: '500',
    color: '#333333',
  },
  driverInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F9F9F9',
    borderRadius: 10,
    padding: 10,
  },
  driverAvatar: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#E8F5E9',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 10,
  },
  driverInitial: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#008000',
  },
  driverDetails: {
    flex: 1,
  },
  driverName: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#333333',
    marginBottom: 2,
  },
  carDetails: {
    fontSize: 12,
    color: '#666666',
  },
  bookingFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    borderTopWidth: 1,
    borderTopColor: '#F0F0F0',
    paddingTop: 15,
  },
  priceContainer: {
    flex: 1,
  },
  priceLabel: {
    fontSize: 12,
    color: '#999999',
    marginBottom: 2,
  },
  priceValue: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#008000',
  },
  cancelButton: {
    backgroundColor: '#FFEBEE',
    borderRadius: 8,
    paddingVertical: 8,
    paddingHorizontal: 15,
    marginRight: 10,
  },
  cancelButtonText: {
    color: '#D32F2F',
    fontSize: 14,
    fontWeight: '500',
  },
  viewButton: {
    backgroundColor: '#008000',
    borderRadius: 8,
    paddingVertical: 8,
    paddingHorizontal: 15,
  },
  viewButtonText: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: '500',
  },
  emptyContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: 30,
    backgroundColor: '#FFFFFF',
    borderRadius: 15,
    marginTop: 20,
  },
  emptyText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333333',
    marginBottom: 5,
  },
  emptySubtext: {
    fontSize: 14,
    color: '#666666',
    textAlign: 'center',
  },
});

export default BookingHistoryScreen;