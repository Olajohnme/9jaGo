import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Share,
  Alert,
  Image,
} from 'react-native';
import { StatusBar } from 'expo-status-bar';
import AsyncStorage from '@react-native-async-storage/async-storage';
import Svg, { Path, Rect, Circle } from 'react-native-svg';

const TicketScreen = ({ route, navigation }) => {
  const { ride, selectedSeats, totalAmount, bookingId } = route.params;
  const [isLoading, setIsLoading] = useState(false);
  
  // Generate QR code data (in a real app, this would be a proper QR code)
  const qrCodeData = `9JARIDE-${bookingId}`;
  
  // Format date for display
  const formatDate = (dateString) => {
    const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
    return new Date(dateString).toLocaleDateString('en-NG', options);
  };
  
  // Handle sharing ticket
  const handleShareTicket = async () => {
    try {
      const shareMessage = `
        🚗 9jaRide Ticket 🚗
        Booking ID: ${bookingId}
        From: ${ride.from}
        To: ${ride.to}
        Date: ${formatDate(ride.date)}
        Time: ${ride.departureTime}
        Seats: ${selectedSeats.join(', ')}
        Amount Paid: ₦${totalAmount.toLocaleString()}
        Driver: ${ride.driver}
        Car: ${ride.carModel}, ${ride.carColor}
      `;
      
      await Share.share({
        message: shareMessage,
        title: '9jaRide Ticket',
      });
    } catch (error) {
      Alert.alert('Error', 'Failed to share ticket. Please try again.');
    }
  };
  
  // Handle downloading ticket (simulated)
  const handleDownloadTicket = () => {
    setIsLoading(true);
    
    // Simulate download process
    setTimeout(() => {
      setIsLoading(false);
      Alert.alert(
        'Ticket Downloaded',
        'Your ticket has been saved to your device.',
        [{ text: 'OK' }]
      );
    }, 1500);
  };
  
  // Render QR code (simplified version)
  const renderQRCode = () => (
    <View style={styles.qrCodeContainer}>
      <Svg height="150" width="150" viewBox="0 0 150 150">
        <Rect x="0" y="0" width="150" height="150" fill="#FFFFFF" />
        <Rect x="20" y="20" width="110" height="110" fill="#000000" />
        <Rect x="35" y="35" width="80" height="80" fill="#FFFFFF" />
        <Rect x="50" y="50" width="50" height="50" fill="#000000" />
        <Rect x="65" y="65" width="20" height="20" fill="#FFFFFF" />
      </Svg>
      <Text style={styles.qrCodeText}>{qrCodeData}</Text>
    </View>
  );
  
  return (
    <View style={styles.container}>
      <StatusBar style="auto" />
      
      <ScrollView contentContainerStyle={styles.scrollContent}>
        <View style={styles.ticketContainer}>
          {/* Ticket Header */}
          <View style={styles.ticketHeader}>
            <Text style={styles.ticketTitle}>9jaRide Ticket</Text>
            <Text style={styles.bookingId}>Booking ID: {bookingId}</Text>
          </View>
          
          {/* Ticket Tear Line */}
          <View style={styles.tearLine}>
            {Array.from({ length: 20 }).map((_, index) => (
              <View key={index} style={styles.tearDot} />
            ))}
          </View>
          
          {/* Ticket Content */}
          <View style={styles.ticketContent}>
            {/* Route Information */}
            <View style={styles.routeContainer}>
              <View style={styles.routePoint}>
                <View style={[styles.routeDot, styles.originDot]} />
                <Text style={styles.routeText}>{ride.from}</Text>
              </View>
              
              <View style={styles.routeLine} />
              
              <View style={styles.routePoint}>
                <View style={[styles.routeDot, styles.destinationDot]} />
                <Text style={styles.routeText}>{ride.to}</Text>
              </View>
            </View>
            
            {/* Trip Details */}
            <View style={styles.detailsGrid}>
              <View style={styles.detailItem}>
                <Text style={styles.detailLabel}>Date</Text>
                <Text style={styles.detailValue}>{formatDate(ride.date)}</Text>
              </View>
              
              <View style={styles.detailItem}>
                <Text style={styles.detailLabel}>Time</Text>
                <Text style={styles.detailValue}>{ride.departureTime}</Text>
              </View>
              
              <View style={styles.detailItem}>
                <Text style={styles.detailLabel}>Seats</Text>
                <Text style={styles.detailValue}>{selectedSeats.join(', ')}</Text>
              </View>
              
              <View style={styles.detailItem}>
                <Text style={styles.detailLabel}>Amount</Text>
                <Text style={styles.detailValue}>₦{totalAmount.toLocaleString()}</Text>
              </View>
            </View>
            
            {/* Driver Information */}
            <View style={styles.driverContainer}>
              <Text style={styles.sectionTitle}>Driver</Text>
              
              <View style={styles.driverInfo}>
                <View style={styles.driverAvatar}>
                  <Text style={styles.driverInitial}>{ride.driver.charAt(0)}</Text>
                </View>
                
                <View style={styles.driverDetails}>
                  <Text style={styles.driverName}>{ride.driver}</Text>
                  <Text style={styles.carInfo}>{ride.carModel}, {ride.carColor}</Text>
                </View>
              </View>
            </View>
            
            {/* QR Code */}
            {renderQRCode()}
            
            {/* Important Notes */}
            <View style={styles.notesContainer}>
              <Text style={styles.notesTitle}>Important Notes:</Text>
              <Text style={styles.notesText}>• Please arrive 15 minutes before departure</Text>
              <Text style={styles.notesText}>• Show this ticket to the driver for check-in</Text>
              <Text style={styles.notesText}>• Cancellation policy: 24 hours notice required</Text>
            </View>
          </View>
        </View>
        
        {/* Action Buttons */}
        <View style={styles.actionButtons}>
          <TouchableOpacity 
            style={[styles.actionButton, styles.shareButton]}
            onPress={handleShareTicket}
          >
            <Text style={styles.actionButtonText}>Share Ticket</Text>
          </TouchableOpacity>
          
          <TouchableOpacity 
            style={[styles.actionButton, styles.downloadButton]}
            onPress={handleDownloadTicket}
            disabled={isLoading}
          >
            <Text style={styles.actionButtonText}>
              {isLoading ? 'Downloading...' : 'Download Ticket'}
            </Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F5F5',
  },
  scrollContent: {
    padding: 20,
  },
  ticketContainer: {
    backgroundColor: '#FFFFFF',
    borderRadius: 15,
    overflow: 'hidden',
    elevation: 3,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  ticketHeader: {
    backgroundColor: '#008000',
    padding: 20,
    alignItems: 'center',
  },
  ticketTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#FFFFFF',
    marginBottom: 5,
  },
  bookingId: {
    fontSize: 14,
    color: '#FFFFFF',
    opacity: 0.8,
  },
  tearLine: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingHorizontal: 10,
    backgroundColor: '#F5F5F5',
    height: 2,
  },
  tearDot: {
    width: 8,
    height: 2,
    backgroundColor: '#FFFFFF',
  },
  ticketContent: {
    padding: 20,
  },
  routeContainer: {
    marginBottom: 20,
  },
  routePoint: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: 5,
  },
  routeDot: {
    width: 12,
    height: 12,
    borderRadius: 6,
    marginRight: 10,
  },
  originDot: {
    backgroundColor: '#008000',
  },
  destinationDot: {
    backgroundColor: '#FF9800',
  },
  routeLine: {
    width: 2,
    height: 30,
    backgroundColor: '#CCCCCC',
    marginLeft: 5,
  },
  routeText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333333',
  },
  detailsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    marginBottom: 20,
    borderWidth: 1,
    borderColor: '#EEEEEE',
    borderRadius: 10,
    overflow: 'hidden',
  },
  detailItem: {
    width: '50%',
    padding: 15,
    borderBottomWidth: 1,
    borderRightWidth: 1,
    borderColor: '#EEEEEE',
  },
  detailLabel: {
    fontSize: 12,
    color: '#666666',
    marginBottom: 5,
  },
  detailValue: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333333',
  },
  driverContainer: {
    marginBottom: 20,
    padding: 15,
    backgroundColor: '#F9F9F9',
    borderRadius: 10,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333333',
    marginBottom: 10,
  },
  driverInfo: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  driverAvatar: {
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: '#E8F5E9',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 15,
  },
  driverInitial: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#008000',
  },
  driverDetails: {
    flex: 1,
  },
  driverName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333333',
    marginBottom: 5,
  },
  carInfo: {
    fontSize: 14,
    color: '#666666',
  },
  qrCodeContainer: {
    alignItems: 'center',
    marginVertical: 20,
  },
  qrCodeText: {
    marginTop: 10,
    fontSize: 14,
    color: '#666666',
  },
  notesContainer: {
    backgroundColor: '#FFF9C4',
    padding: 15,
    borderRadius: 10,
  },
  notesTitle: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#333333',
    marginBottom: 5,
  },
  notesText: {
    fontSize: 12,
    color: '#666666',
    marginBottom: 3,
  },
  actionButtons: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 20,
  },
  actionButton: {
    flex: 1,
    paddingVertical: 15,
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
    marginHorizontal: 5,
  },
  shareButton: {
    backgroundColor: '#008000',
  },
  downloadButton: {
    backgroundColor: '#FF9800',
  },
  actionButtonText: {
    color: '#FFFFFF',
    fontWeight: 'bold',
    fontSize: 16,
  },
});

export default TicketScreen;