import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Alert,
  Image,
  Modal,
} from 'react-native';
import { StatusBar } from 'expo-status-bar';

const RideDetailsScreen = ({ route, navigation }) => {
  const { ride } = route.params;
  const [selectedSeats, setSelectedSeats] = useState([]);
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  
  // Mock data for available seats
  const totalSeats = 4;
  const bookedSeats = Array(totalSeats - ride.seatsAvailable)
    .fill()
    .map((_, index) => index + 1);
  
  const handleSeatSelection = (seatNumber) => {
    if (bookedSeats.includes(seatNumber)) {
      // Seat is already booked
      Alert.alert('Seat Unavailable', 'This seat has already been booked.');
      return;
    }
    
    if (selectedSeats.includes(seatNumber)) {
      // Deselect the seat
      setSelectedSeats(selectedSeats.filter(seat => seat !== seatNumber));
    } else {
      // Select the seat
      setSelectedSeats([...selectedSeats, seatNumber]);
    }
  };
  
  const handleBookNow = () => {
    if (selectedSeats.length === 0) {
      Alert.alert('No Seats Selected', 'Please select at least one seat to continue.');
      return;
    }
    
    setShowPaymentModal(true);
  };
  
  const handlePayment = () => {
    // Close payment modal
    setShowPaymentModal(false);
    
    // Navigate to payment screen with ride and seat details
    navigation.navigate('Payment', {
      ride,
      selectedSeats,
      totalAmount: calculateTotalAmount(),
    });
  };
  
  const calculateTotalAmount = () => {
    // Remove the currency symbol and commas from the price string
    const priceValue = parseFloat(ride.price.replace('₦', '').replace(',', ''));
    return priceValue * selectedSeats.length;
  };
  
  const formatTotalAmount = () => {
    return `₦${calculateTotalAmount().toLocaleString()}`;
  };
  
  const renderSeatMap = () => {
    return (
      <View style={styles.seatMapContainer}>
        <View style={styles.carOutline}>
          <View style={styles.carFront}>
            <View style={styles.steeringWheel} />
          </View>
          
          <View style={styles.seatRow}>
            <TouchableOpacity
              style={[
                styles.seat,
                bookedSeats.includes(1) && styles.bookedSeat,
                selectedSeats.includes(1) && styles.selectedSeat,
              ]}
              onPress={() => handleSeatSelection(1)}
            >
              <Text style={styles.seatText}>1</Text>
            </TouchableOpacity>
            
            <TouchableOpacity
              style={[
                styles.seat,
                bookedSeats.includes(2) && styles.bookedSeat,
                selectedSeats.includes(2) && styles.selectedSeat,
              ]}
              onPress={() => handleSeatSelection(2)}
            >
              <Text style={styles.seatText}>2</Text>
            </TouchableOpacity>
          </View>
          
          <View style={styles.seatRow}>
            <TouchableOpacity
              style={[
                styles.seat,
                bookedSeats.includes(3) && styles.bookedSeat,
                selectedSeats.includes(3) && styles.selectedSeat,
              ]}
              onPress={() => handleSeatSelection(3)}
            >
              <Text style={styles.seatText}>3</Text>
            </TouchableOpacity>
            
            <TouchableOpacity
              style={[
                styles.seat,
                bookedSeats.includes(4) && styles.bookedSeat,
                selectedSeats.includes(4) && styles.selectedSeat,
              ]}
              onPress={() => handleSeatSelection(4)}
            >
              <Text style={styles.seatText}>4</Text>
            </TouchableOpacity>
          </View>
        </View>
        
        <View style={styles.seatLegend}>
          <View style={styles.legendItem}>
            <View style={[styles.legendIndicator, styles.availableLegend]} />
            <Text style={styles.legendText}>Available</Text>
          </View>
          
          <View style={styles.legendItem}>
            <View style={[styles.legendIndicator, styles.bookedLegend]} />
            <Text style={styles.legendText}>Booked</Text>
          </View>
          
          <View style={styles.legendItem}>
            <View style={[styles.legendIndicator, styles.selectedLegend]} />
            <Text style={styles.legendText}>Selected</Text>
          </View>
        </View>
      </View>
    );
  };
  
  return (
    <View style={styles.container}>
      <StatusBar style="light" />
      
      <View style={styles.header}>
        <TouchableOpacity
          style={styles.backButton}
          onPress={() => navigation.goBack()}
        >
          <Text style={styles.backButtonText}>←</Text>
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Ride Details</Text>
        <View style={styles.placeholder} />
      </View>
      
      <ScrollView contentContainerStyle={styles.scrollContent}>
        <View style={styles.routeCard}>
          <View style={styles.routeHeader}>
            <View style={styles.locationContainer}>
              <Text style={styles.fromText}>{ride.from}</Text>
              <View style={styles.arrowContainer}>
                <View style={styles.arrowLine} />
                <Text style={styles.arrowHead}>▶</Text>
              </View>
              <Text style={styles.toText}>{ride.to}</Text>
            </View>
          </View>
          
          <View style={styles.routeDetails}>
            <View style={styles.detailItem}>
              <Text style={styles.detailLabel}>Date</Text>
              <Text style={styles.detailValue}>{ride.date}</Text>
            </View>
            
            <View style={styles.detailItem}>
              <Text style={styles.detailLabel}>Time</Text>
              <Text style={styles.detailValue}>{ride.time}</Text>
            </View>
            
            <View style={styles.detailItem}>
              <Text style={styles.detailLabel}>Price</Text>
              <Text style={styles.detailValue}>{ride.price}/seat</Text>
            </View>
          </View>
        </View>
        
        <View style={styles.driverCard}>
          <Text style={styles.sectionTitle}>Driver Information</Text>
          
          <View style={styles.driverInfo}>
            <View style={styles.driverAvatar}>
              <Text style={styles.driverInitial}>{ride.driver.charAt(0)}</Text>
            </View>
            
            <View style={styles.driverDetails}>
              <Text style={styles.driverName}>{ride.driver}</Text>
              <View style={styles.ratingContainer}>
                <Text style={styles.ratingText}>★ {ride.rating}</Text>
              </View>
            </View>
          </View>
          
          <View style={styles.carInfo}>
            <Text style={styles.carInfoLabel}>Vehicle:</Text>
            <Text style={styles.carInfoValue}>{ride.carModel}, {ride.carColor}</Text>
          </View>
        </View>
        
        <View style={styles.seatsCard}>
          <Text style={styles.sectionTitle}>Select Seats</Text>
          <Text style={styles.seatsSubtitle}>
            {ride.seatsAvailable} seat{ride.seatsAvailable !== 1 ? 's' : ''} available
          </Text>
          
          {renderSeatMap()}
          
          {selectedSeats.length > 0 && (
            <View style={styles.selectedSeatsInfo}>
              <Text style={styles.selectedSeatsText}>
                Selected: {selectedSeats.join(', ')}
              </Text>
              <Text style={styles.totalAmountText}>
                Total: {formatTotalAmount()}
              </Text>
            </View>
          )}
        </View>
      </ScrollView>
      
      <View style={styles.footer}>
        <TouchableOpacity
          style={styles.bookButton}
          onPress={handleBookNow}
        >
          <Text style={styles.bookButtonText}>
            Book Now {selectedSeats.length > 0 ? `(${formatTotalAmount()})` : ''}
          </Text>
        </TouchableOpacity>
      </View>
      
      <Modal
        visible={showPaymentModal}
        transparent={true}
        animationType="slide"
        onRequestClose={() => setShowPaymentModal(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.paymentModal}>
            <Text style={styles.paymentModalTitle}>Confirm Booking</Text>
            
            <View style={styles.paymentDetails}>
              <View style={styles.paymentRow}>
                <Text style={styles.paymentLabel}>Route:</Text>
                <Text style={styles.paymentValue}>{ride.from} → {ride.to}</Text>
              </View>
              
              <View style={styles.paymentRow}>
                <Text style={styles.paymentLabel}>Date & Time:</Text>
                <Text style={styles.paymentValue}>{ride.date}, {ride.time}</Text>
              </View>
              
              <View style={styles.paymentRow}>
                <Text style={styles.paymentLabel}>Seats:</Text>
                <Text style={styles.paymentValue}>{selectedSeats.join(', ')}</Text>
              </View>
              
              <View style={styles.paymentRow}>
                <Text style={styles.paymentLabel}>Price per seat:</Text>
                <Text style={styles.paymentValue}>{ride.price}</Text>
              </View>
              
              <View style={[styles.paymentRow, styles.totalRow]}>
                <Text style={styles.totalLabel}>Total Amount:</Text>
                <Text style={styles.totalValue}>{formatTotalAmount()}</Text>
              </View>
            </View>
            
            <View style={styles.modalButtons}>
              <TouchableOpacity
                style={styles.cancelButton}
                onPress={() => setShowPaymentModal(false)}
              >
                <Text style={styles.cancelButtonText}>Cancel</Text>
              </TouchableOpacity>
              
              <TouchableOpacity
                style={styles.proceedButton}
                onPress={handlePayment}
              >
                <Text style={styles.proceedButtonText}>Proceed to Payment</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F5F5',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: '#008000',
    paddingTop: 50,
    paddingBottom: 15,
    paddingHorizontal: 20,
  },
  backButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  backButtonText: {
    color: '#FFFFFF',
    fontSize: 24,
    fontWeight: 'bold',
  },
  headerTitle: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: 'bold',
  },
  placeholder: {
    width: 40,
  },
  scrollContent: {
    padding: 20,
  },
  routeCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 15,
    padding: 20,
    marginBottom: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  routeHeader: {
    marginBottom: 20,
  },
  locationContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  fromText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333333',
  },
  arrowContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginHorizontal: 10,
  },
  arrowLine: {
    height: 1,
    width: 50,
    backgroundColor: '#CCCCCC',
  },
  arrowHead: {
    color: '#CCCCCC',
    fontSize: 12,
  },
  toText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333333',
  },
  routeDetails: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  detailItem: {
    alignItems: 'center',
  },
  detailLabel: {
    fontSize: 12,
    color: '#999999',
    marginBottom: 5,
  },
  detailValue: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333333',
  },
  driverCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 15,
    padding: 20,
    marginBottom: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333333',
    marginBottom: 15,
  },
  driverInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 15,
  },
  driverAvatar: {
    width: 60,
    height: 60,
    borderRadius: 30,
    backgroundColor: '#E8F5E9',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 15,
  },
  driverInitial: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#008000',
  },
  driverDetails: {
    flex: 1,
  },
  driverName: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333333',
    marginBottom: 5,
  },
  ratingContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  ratingText: {
    fontSize: 14,
    color: '#FFC107',
  },
  carInfo: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  carInfoLabel: {
    fontSize: 14,
    color: '#666666',
    marginRight: 5,
  },
  carInfoValue: {
    fontSize: 14,
    color: '#333333',
  },
  seatsCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 15,
    padding: 20,
    marginBottom: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  seatsSubtitle: {
    fontSize: 14,
    color: '#666666',
    marginBottom: 20,
  },
  seatMapContainer: {
    alignItems: 'center',
    marginBottom: 20,
  },
  carOutline: {
    width: 200,
    height: 280,
    borderWidth: 2,
    borderColor: '#CCCCCC',
    borderRadius: 20,
    padding: 20,
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  carFront: {
    width: 120,
    height: 60,
    borderWidth: 2,
    borderColor: '#CCCCCC',
    borderRadius: 30,
    alignItems: 'center',
    justifyContent: 'center',
  },
  steeringWheel: {
    width: 30,
    height: 30,
    borderWidth: 2,
    borderColor: '#CCCCCC',
    borderRadius: 15,
  },
  seatRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: '100%',
    paddingHorizontal: 10,
  },
  seat: {
    width: 60,
    height: 60,
    borderRadius: 10,
    backgroundColor: '#E8F5E9',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#008000',
  },
  bookedSeat: {
    backgroundColor: '#EEEEEE',
    borderColor: '#CCCCCC',
  },
  selectedSeat: {
    backgroundColor: '#008000',
  },
  seatText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#008000',
  },
  seatLegend: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    width: '100%',
    marginTop: 20,
  },
  legendItem: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  legendIndicator: {
    width: 16,
    height: 16,
    borderRadius: 4,
    marginRight: 5,
  },
  availableLegend: {
    backgroundColor: '#E8F5E9',
    borderWidth: 1,
    borderColor: '#008000',
  },
  bookedLegend: {
    backgroundColor: '#EEEEEE',
    borderWidth: 1,
    borderColor: '#CCCCCC',
  },
  selectedLegend: {
    backgroundColor: '#008000',
    borderWidth: 1,
    borderColor: '#008000',
  },
  legendText: {
    fontSize: 12,
    color: '#666666',
  },
  selectedSeatsInfo: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: 20,
    paddingTop: 15,
    borderTopWidth: 1,
    borderTopColor: '#EEEEEE',
  },
  selectedSeatsText: {
    fontSize: 14,
    color: '#333333',
  },
  totalAmountText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#008000',
  },
  footer: {
    backgroundColor: '#FFFFFF',
    padding: 20,
    borderTopWidth: 1,
    borderTopColor: '#EEEEEE',
  },
  bookButton: {
    backgroundColor: '#008000',
    borderRadius: 10,
    padding: 15,
    alignItems: 'center',
  },
  bookButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'flex-end',
  },
  paymentModal: {
    backgroundColor: '#FFFFFF',
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    padding: 20,
  },
  paymentModalTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#333333',
    marginBottom: 20,
    textAlign: 'center',
  },
  paymentDetails: {
    marginBottom: 20,
  },
  paymentRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 10,
  },
  paymentLabel: {
    fontSize: 14,
    color: '#666666',
  },
  paymentValue: {
    fontSize: 14,
    color: '#333333',
    fontWeight: '500',
  },
  totalRow: {
    marginTop: 10,
    paddingTop: 10,
    borderTopWidth: 1,
    borderTopColor: '#EEEEEE',
  },
  totalLabel: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333333',
  },
  totalValue: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#008000',
  },
  modalButtons: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  cancelButton: {
    flex: 1,
    backgroundColor: '#F5F5F5',
    borderRadius: 10,
    padding: 15,
    alignItems: 'center',
    marginRight: 10,
  },
  cancelButtonText: {
    color: '#666666',
    fontSize: 16,
    fontWeight: '500',
  },
  proceedButton: {
    flex: 1,
    backgroundColor: '#008000',
    borderRadius: 10,
    padding: 15,
    alignItems: 'center',
  },
  proceedButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
});

export default RideDetailsScreen;