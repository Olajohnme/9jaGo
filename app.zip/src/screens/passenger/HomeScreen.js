import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  TextInput,
  FlatList,
  Image,
  ActivityIndicator,
} from 'react-native';
import { StatusBar } from 'expo-status-bar';
import AsyncStorage from '@react-native-async-storage/async-storage';

const HomeScreen = ({ navigation }) => {
  const [userName, setUserName] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  const [featuredRides, setFeaturedRides] = useState([]);
  const [recentSearches, setRecentSearches] = useState([]);

  useEffect(() => {
    // Load user data
    const loadUserData = async () => {
      try {
        const email = await AsyncStorage.getItem('userEmail');
        if (email) {
          // Extract name from email for demo purposes
          const name = email.split('@')[0];
          setUserName(name.charAt(0).toUpperCase() + name.slice(1));
        }
      } catch (error) {
        console.log('Error loading user data:', error);
      }
    };

    // Load featured rides (mock data for demo)
    const loadFeaturedRides = () => {
      // Simulate API call
      setTimeout(() => {
        const mockRides = [
          {
            id: '1',
            from: 'Lagos',
            to: 'Abuja',
            date: '2023-08-15',
            time: '08:00 AM',
            price: '₦15,000',
            driver: 'John Doe',
            rating: 4.8,
            seatsAvailable: 3,
            carModel: 'Toyota Camry',
            carColor: 'Black',
          },
          {
            id: '2',
            from: 'Port Harcourt',
            to: 'Calabar',
            date: '2023-08-16',
            time: '09:30 AM',
            price: '₦8,500',
            driver: 'Sarah James',
            rating: 4.5,
            seatsAvailable: 2,
            carModel: 'Honda Accord',
            carColor: 'Silver',
          },
          {
            id: '3',
            from: 'Enugu',
            to: 'Owerri',
            date: '2023-08-17',
            time: '10:00 AM',
            price: '₦5,000',
            driver: 'Michael Obi',
            rating: 4.7,
            seatsAvailable: 4,
            carModel: 'Kia Sportage',
            carColor: 'White',
          },
        ];
        setFeaturedRides(mockRides);
        setIsLoading(false);
      }, 1500);
    };

    // Load recent searches (mock data for demo)
    const loadRecentSearches = async () => {
      try {
        const searches = await AsyncStorage.getItem('recentSearches');
        if (searches) {
          setRecentSearches(JSON.parse(searches));
        } else {
          // Mock data for first-time users
          const mockSearches = [
            { from: 'Lagos', to: 'Ibadan' },
            { from: 'Abuja', to: 'Kaduna' },
          ];
          setRecentSearches(mockSearches);
          await AsyncStorage.setItem('recentSearches', JSON.stringify(mockSearches));
        }
      } catch (error) {
        console.log('Error loading recent searches:', error);
      }
    };

    loadUserData();
    loadFeaturedRides();
    loadRecentSearches();
  }, []);

  const handleSearch = () => {
    navigation.navigate('Search');
  };

  const handleRidePress = (ride) => {
    navigation.navigate('RideDetails', { ride });
  };

  const renderRideItem = ({ item }) => (
    <TouchableOpacity
      style={styles.rideCard}
      onPress={() => handleRidePress(item)}
    >
      <View style={styles.rideHeader}>
        <View style={styles.locationContainer}>
          <Text style={styles.fromText}>{item.from}</Text>
          <View style={styles.arrowContainer}>
            <View style={styles.arrowLine} />
            <Text style={styles.arrowHead}>▶</Text>
          </View>
          <Text style={styles.toText}>{item.to}</Text>
        </View>
        <Text style={styles.priceText}>{item.price}</Text>
      </View>
      
      <View style={styles.rideDetails}>
        <View style={styles.detailItem}>
          <Text style={styles.detailLabel}>Date:</Text>
          <Text style={styles.detailValue}>{item.date}</Text>
        </View>
        <View style={styles.detailItem}>
          <Text style={styles.detailLabel}>Time:</Text>
          <Text style={styles.detailValue}>{item.time}</Text>
        </View>
        <View style={styles.detailItem}>
          <Text style={styles.detailLabel}>Available:</Text>
          <Text style={styles.detailValue}>{item.seatsAvailable} seats</Text>
        </View>
      </View>
      
      <View style={styles.driverInfo}>
        <View style={styles.driverAvatar}>
          <Text style={styles.driverInitial}>{item.driver.charAt(0)}</Text>
        </View>
        <View style={styles.driverDetails}>
          <Text style={styles.driverName}>{item.driver}</Text>
          <View style={styles.ratingContainer}>
            <Text style={styles.ratingText}>★ {item.rating}</Text>
            <Text style={styles.carInfo}>{item.carModel}, {item.carColor}</Text>
          </View>
        </View>
      </View>
    </TouchableOpacity>
  );

  return (
    <View style={styles.container}>
      <StatusBar style="dark" />
      
      <ScrollView contentContainerStyle={styles.scrollContent}>
        <View style={styles.header}>
          <View>
            <Text style={styles.welcomeText}>Welcome back,</Text>
            <Text style={styles.userName}>{userName || 'Traveler'}</Text>
          </View>
          <TouchableOpacity style={styles.profileButton}>
            <View style={styles.profileIcon}>
              <Text style={styles.profileInitial}>{userName ? userName.charAt(0) : 'U'}</Text>
            </View>
          </TouchableOpacity>
        </View>
        
        <TouchableOpacity style={styles.searchBar} onPress={handleSearch}>
          <View style={styles.searchIcon}>
            <Text>🔍</Text>
          </View>
          <Text style={styles.searchPlaceholder}>Where would you like to go?</Text>
        </TouchableOpacity>
        
        {recentSearches.length > 0 && (
          <View style={styles.recentSearchesContainer}>
            <Text style={styles.sectionTitle}>Recent Searches</Text>
            <ScrollView horizontal showsHorizontalScrollIndicator={false}>
              {recentSearches.map((search, index) => (
                <TouchableOpacity key={index} style={styles.recentSearchItem}>
                  <Text style={styles.recentSearchText}>
                    {search.from} → {search.to}
                  </Text>
                </TouchableOpacity>
              ))}
            </ScrollView>
          </View>
        )}
        
        <View style={styles.featuredContainer}>
          <Text style={styles.sectionTitle}>Featured Rides</Text>
          
          {isLoading ? (
            <ActivityIndicator size="large" color="#008000" style={styles.loader} />
          ) : (
            <FlatList
              data={featuredRides}
              renderItem={renderRideItem}
              keyExtractor={(item) => item.id}
              scrollEnabled={false}
              contentContainerStyle={styles.ridesList}
            />
          )}
        </View>
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F5F5',
  },
  scrollContent: {
    padding: 20,
    paddingTop: 60,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20,
  },
  welcomeText: {
    fontSize: 16,
    color: '#666666',
  },
  userName: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#333333',
  },
  profileButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#008000',
    justifyContent: 'center',
    alignItems: 'center',
  },
  profileIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#008000',
    justifyContent: 'center',
    alignItems: 'center',
  },
  profileInitial: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: 'bold',
  },
  searchBar: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
    borderRadius: 10,
    padding: 15,
    marginBottom: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  searchIcon: {
    marginRight: 10,
  },
  searchPlaceholder: {
    color: '#999999',
    fontSize: 16,
  },
  recentSearchesContainer: {
    marginBottom: 20,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333333',
    marginBottom: 15,
  },
  recentSearchItem: {
    backgroundColor: '#FFFFFF',
    paddingHorizontal: 15,
    paddingVertical: 10,
    borderRadius: 20,
    marginRight: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 1,
  },
  recentSearchText: {
    color: '#333333',
    fontSize: 14,
  },
  featuredContainer: {
    marginBottom: 20,
  },
  loader: {
    marginTop: 20,
  },
  ridesList: {
    paddingBottom: 20,
  },
  rideCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 15,
    padding: 15,
    marginBottom: 15,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  rideHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 15,
  },
  locationContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  fromText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333333',
  },
  arrowContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginHorizontal: 10,
  },
  arrowLine: {
    height: 1,
    width: 30,
    backgroundColor: '#CCCCCC',
  },
  arrowHead: {
    color: '#CCCCCC',
    fontSize: 12,
  },
  toText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333333',
  },
  priceText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#008000',
  },
  rideDetails: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 15,
    paddingBottom: 15,
    borderBottomWidth: 1,
    borderBottomColor: '#EEEEEE',
  },
  detailItem: {
    flexDirection: 'column',
  },
  detailLabel: {
    fontSize: 12,
    color: '#999999',
    marginBottom: 5,
  },
  detailValue: {
    fontSize: 14,
    color: '#333333',
    fontWeight: '500',
  },
  driverInfo: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  driverAvatar: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#E8F5E9',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 10,
  },
  driverInitial: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#008000',
  },
  driverDetails: {
    flex: 1,
  },
  driverName: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#333333',
    marginBottom: 5,
  },
  ratingContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  ratingText: {
    fontSize: 12,
    color: '#FFC107',
    marginRight: 10,
  },
  carInfo: {
    fontSize: 12,
    color: '#999999',
  },
});

export default HomeScreen;