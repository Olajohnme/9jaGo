import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  FlatList,
  Image,
  ScrollView,
  Modal,
  ActivityIndicator,
  KeyboardAvoidingView,
  Platform,
} from 'react-native';
import { StatusBar } from 'expo-status-bar';
import AsyncStorage from '@react-native-async-storage/async-storage';

const SearchRidesScreen = ({ navigation }) => {
  const [searchParams, setSearchParams] = useState({
    from: '',
    to: '',
    date: '',
    passengers: '1',
  });
  
  const [isSearching, setIsSearching] = useState(false);
  const [searchResults, setSearchResults] = useState([]);
  const [recentSearches, setRecentSearches] = useState([]);
  const [showDatePicker, setShowDatePicker] = useState(false);
  const [selectedDate, setSelectedDate] = useState(new Date());
  
  // Popular destinations in Nigeria
  const popularDestinations = [
    'Lagos',
    'Abuja',
    'Port Harcourt',
    'Ibadan',
    'Kano',
    'Enugu',
    'Calabar',
    'Benin City',
  ];
  
  useEffect(() => {
    loadRecentSearches();
  }, []);
  
  const loadRecentSearches = async () => {
    try {
      const searches = await AsyncStorage.getItem('recentSearches');
      if (searches) {
        setRecentSearches(JSON.parse(searches));
      }
    } catch (error) {
      console.log('Error loading recent searches:', error);
    }
  };
  
  const saveRecentSearch = async () => {
    try {
      // Only save if both from and to are provided
      if (searchParams.from && searchParams.to) {
        const newSearch = {
          id: Date.now().toString(),
          from: searchParams.from,
          to: searchParams.to,
          date: searchParams.date || new Date().toISOString().split('T')[0],
          timestamp: new Date().toISOString(),
        };
        
        // Add to recent searches and keep only the latest 5
        const updatedSearches = [newSearch, ...recentSearches.filter(s => 
          s.from !== newSearch.from || s.to !== newSearch.to
        )].slice(0, 5);
        
        setRecentSearches(updatedSearches);
        await AsyncStorage.setItem('recentSearches', JSON.stringify(updatedSearches));
      }
    } catch (error) {
      console.log('Error saving recent search:', error);
    }
  };
  
  const handleSearch = () => {
    if (!searchParams.from || !searchParams.to) {
      alert('Please enter both origin and destination');
      return;
    }
    
    setIsSearching(true);
    
    // Save this search to recent searches
    saveRecentSearch();
    
    // Simulate API call to search for rides
    setTimeout(() => {
      // Generate mock search results
      const mockResults = generateMockResults();
      setSearchResults(mockResults);
      setIsSearching(false);
    }, 1500);
  };
  
  const generateMockResults = () => {
    // Generate between 3-8 mock results
    const count = Math.floor(Math.random() * 6) + 3;
    const results = [];
    
    const currentDate = new Date();
    let searchDate;
    
    if (searchParams.date) {
      searchDate = new Date(searchParams.date);
    } else {
      searchDate = new Date();
      searchDate.setDate(currentDate.getDate() + Math.floor(Math.random() * 7));
    }
    
    // Format date as YYYY-MM-DD
    const formattedDate = searchDate.toISOString().split('T')[0];
    
    for (let i = 0; i < count; i++) {
      // Generate a random time between 6 AM and 10 PM
      const hour = Math.floor(Math.random() * 16) + 6;
      const minute = Math.floor(Math.random() * 60);
      const formattedTime = `${hour.toString().padStart(2, '0')}:${minute.toString().padStart(2, '0')}`;
      
      // Generate a random price between ₦2,000 and ₦15,000
      const price = Math.floor(Math.random() * 13000) + 2000;
      
      // Generate random available seats between 1 and 4
      const availableSeats = Math.floor(Math.random() * 4) + 1;
      
      // Generate random driver names
      const driverFirstNames = ['Oluwaseun', 'Chijioke', 'Adebayo', 'Ngozi', 'Emeka', 'Fatima', 'Ibrahim', 'Amina'];
      const driverLastNames = ['Adeyemi', 'Okonkwo', 'Ojo', 'Nwachukwu', 'Okafor', 'Mohammed', 'Abubakar', 'Yusuf'];
      const driverName = `${driverFirstNames[Math.floor(Math.random() * driverFirstNames.length)]} ${driverLastNames[Math.floor(Math.random() * driverLastNames.length)]}`;
      
      // Generate random car models
      const carModels = ['Toyota Camry', 'Honda Accord', 'Toyota Corolla', 'Kia Rio', 'Hyundai Elantra', 'Mazda 3', 'Ford Focus', 'Nissan Sentra'];
      const carModel = carModels[Math.floor(Math.random() * carModels.length)];
      
      // Generate random car colors
      const carColors = ['Black', 'White', 'Silver', 'Gray', 'Blue', 'Red'];
      const carColor = carColors[Math.floor(Math.random() * carColors.length)];
      
      // Generate random ratings between 3.5 and 5.0
      const rating = (Math.random() * 1.5 + 3.5).toFixed(1);
      
      results.push({
        id: `ride-${i + 1}`,
        from: searchParams.from,
        to: searchParams.to,
        date: formattedDate,
        time: formattedTime,
        price: price,
        availableSeats: availableSeats,
        driver: {
          name: driverName,
          rating: rating,
          trips: Math.floor(Math.random() * 100) + 10,
        },
        car: {
          model: carModel,
          color: carColor,
          licensePlate: `${['LAG', 'ABJ', 'PHC', 'KAN', 'ENU'][Math.floor(Math.random() * 5)]}-${Math.floor(Math.random() * 900) + 100}-${String.fromCharCode(65 + Math.floor(Math.random() * 26))}${String.fromCharCode(65 + Math.floor(Math.random() * 26))}`,
        },
      });
    }
    
    return results;
  };
  
  const handleSelectRecentSearch = (search) => {
    setSearchParams({
      ...searchParams,
      from: search.from,
      to: search.to,
      date: search.date,
    });
  };
  
  const handleSelectPopularDestination = (destination, type) => {
    if (type === 'from') {
      setSearchParams({ ...searchParams, from: destination });
    } else {
      setSearchParams({ ...searchParams, to: destination });
    }
  };
  
  const formatDate = (dateString) => {
    if (!dateString) return '';
    
    const date = new Date(dateString);
    return date.toLocaleDateString('en-NG', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    });
  };
  
  const handleSelectRide = (ride) => {
    navigation.navigate('RideDetails', { ride });
  };
  
  const renderSearchResult = ({ item }) => (
    <TouchableOpacity 
      style={styles.resultCard}
      onPress={() => handleSelectRide(item)}
    >
      <View style={styles.routeContainer}>
        <Text style={styles.routeText}>{item.from} to {item.to}</Text>
        <Text style={styles.dateTimeText}>{formatDate(item.date)} • {item.time}</Text>
      </View>
      
      <View style={styles.resultDivider} />
      
      <View style={styles.detailsContainer}>
        <View style={styles.priceSeatsContainer}>
          <Text style={styles.priceText}>₦{item.price.toLocaleString()}</Text>
          <Text style={styles.seatsText}>{item.availableSeats} {item.availableSeats === 1 ? 'seat' : 'seats'} left</Text>
        </View>
        
        <View style={styles.driverContainer}>
          <View style={styles.driverAvatar}>
            <Text style={styles.driverInitial}>{item.driver.name.charAt(0)}</Text>
          </View>
          <View style={styles.driverInfo}>
            <Text style={styles.driverName}>{item.driver.name}</Text>
            <View style={styles.ratingContainer}>
              <Text style={styles.ratingText}>{item.driver.rating}</Text>
              <Text style={styles.starIcon}>★</Text>
            </View>
          </View>
        </View>
        
        <View style={styles.carContainer}>
          <Text style={styles.carText}>{item.car.model} • {item.car.color}</Text>
        </View>
      </View>
    </TouchableOpacity>
  );
  
  const renderRecentSearch = ({ item }) => (
    <TouchableOpacity 
      style={styles.recentSearchItem}
      onPress={() => handleSelectRecentSearch(item)}
    >
      <View style={styles.recentSearchIcon}>
        <Text style={styles.recentSearchIconText}>🔍</Text>
      </View>
      <View style={styles.recentSearchInfo}>
        <Text style={styles.recentSearchRoute}>{item.from} to {item.to}</Text>
        <Text style={styles.recentSearchDate}>{formatDate(item.date)}</Text>
      </View>
    </TouchableOpacity>
  );
  
  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      style={styles.container}
    >
      <StatusBar style="light" />
      
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Find a Ride</Text>
      </View>
      
      <ScrollView contentContainerStyle={styles.scrollContent}>
        <View style={styles.searchForm}>
          <View style={styles.inputContainer}>
            <Text style={styles.inputLabel}>From</Text>
            <TextInput
              style={styles.input}
              placeholder="Enter pickup location"
              value={searchParams.from}
              onChangeText={(text) => setSearchParams({ ...searchParams, from: text })}
            />
          </View>
          
          <View style={styles.inputContainer}>
            <Text style={styles.inputLabel}>To</Text>
            <TextInput
              style={styles.input}
              placeholder="Enter destination"
              value={searchParams.to}
              onChangeText={(text) => setSearchParams({ ...searchParams, to: text })}
            />
          </View>
          
          <View style={styles.inputContainer}>
            <Text style={styles.inputLabel}>Date</Text>
            <TextInput
              style={styles.input}
              placeholder="YYYY-MM-DD"
              value={searchParams.date}
              onChangeText={(text) => setSearchParams({ ...searchParams, date: text })}
            />
          </View>
          
          <View style={styles.inputContainer}>
            <Text style={styles.inputLabel}>Passengers</Text>
            <TextInput
              style={styles.input}
              placeholder="Number of passengers"
              value={searchParams.passengers}
              onChangeText={(text) => setSearchParams({ ...searchParams, passengers: text })}
              keyboardType="numeric"
            />
          </View>
          
          <TouchableOpacity
            style={styles.searchButton}
            onPress={handleSearch}
          >
            <Text style={styles.searchButtonText}>Search</Text>
          </TouchableOpacity>
        </View>
        
        {isSearching ? (
          <View style={styles.loadingContainer}>
            <ActivityIndicator size="large" color="#008000" />
            <Text style={styles.loadingText}>Searching for rides...</Text>
          </View>
        ) : searchResults.length > 0 ? (
          <View style={styles.resultsContainer}>
            <Text style={styles.resultsTitle}>
              {searchResults.length} {searchResults.length === 1 ? 'ride' : 'rides'} found
            </Text>
            <FlatList
              data={searchResults}
              renderItem={renderSearchResult}
              keyExtractor={(item) => item.id}
              scrollEnabled={false}
            />
          </View>
        ) : (
          <>
            {recentSearches.length > 0 && (
              <View style={styles.recentSearchesContainer}>
                <Text style={styles.sectionTitle}>Recent Searches</Text>
                <FlatList
                  data={recentSearches}
                  renderItem={renderRecentSearch}
                  keyExtractor={(item) => item.id}
                  scrollEnabled={false}
                />
              </View>
            )}
            
            <View style={styles.popularDestinationsContainer}>
              <Text style={styles.sectionTitle}>Popular Destinations</Text>
              
              <View style={styles.popularDestinationsSection}>
                <Text style={styles.popularDestinationsLabel}>From:</Text>
                <View style={styles.popularDestinationsList}>
                  {popularDestinations.slice(0, 4).map((destination, index) => (
                    <TouchableOpacity
                      key={`from-${index}`}
                      style={styles.popularDestinationItem}
                      onPress={() => handleSelectPopularDestination(destination, 'from')}
                    >
                      <Text style={styles.popularDestinationText}>{destination}</Text>
                    </TouchableOpacity>
                  ))}
                </View>
              </View>
              
              <View style={styles.popularDestinationsSection}>
                <Text style={styles.popularDestinationsLabel}>To:</Text>
                <View style={styles.popularDestinationsList}>
                  {popularDestinations.slice(4, 8).map((destination, index) => (
                    <TouchableOpacity
                      key={`to-${index}`}
                      style={styles.popularDestinationItem}
                      onPress={() => handleSelectPopularDestination(destination, 'to')}
                    >
                      <Text style={styles.popularDestinationText}>{destination}</Text>
                    </TouchableOpacity>
                  ))}
                </View>
              </View>
            </View>
          </>
        )}
      </ScrollView>
    </KeyboardAvoidingView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F5F5',
  },
  header: {
    backgroundColor: '#008000',
    paddingTop: 50,
    paddingBottom: 15,
    paddingHorizontal: 20,
  },
  headerTitle: {
    color: '#FFFFFF',
    fontSize: 20,
    fontWeight: 'bold',
  },
  scrollContent: {
    padding: 20,
    paddingBottom: 40,
  },
  searchForm: {
    backgroundColor: '#FFFFFF',
    borderRadius: 15,
    padding: 20,
    marginBottom: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  inputContainer: {
    marginBottom: 15,
  },
  inputLabel: {
    fontSize: 14,
    color: '#666666',
    marginBottom: 5,
  },
  input: {
    borderWidth: 1,
    borderColor: '#DDDDDD',
    borderRadius: 8,
    paddingHorizontal: 15,
    paddingVertical: 10,
    fontSize: 16,
    backgroundColor: '#F9F9F9',
  },
  searchButton: {
    backgroundColor: '#008000',
    borderRadius: 8,
    paddingVertical: 15,
    alignItems: 'center',
    marginTop: 10,
  },
  searchButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
  loadingContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: 40,
  },
  loadingText: {
    marginTop: 10,
    fontSize: 16,
    color: '#666666',
  },
  resultsContainer: {
    marginBottom: 20,
  },
  resultsTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333333',
    marginBottom: 15,
  },
  resultCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 15,
    marginBottom: 15,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
    overflow: 'hidden',
  },
  routeContainer: {
    padding: 15,
    backgroundColor: '#F9F9F9',
  },
  routeText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333333',
    marginBottom: 5,
  },
  dateTimeText: {
    fontSize: 14,
    color: '#666666',
  },
  resultDivider: {
    height: 1,
    backgroundColor: '#EEEEEE',
  },
  detailsContainer: {
    padding: 15,
  },
  priceSeatsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 15,
  },
  priceText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#008000',
  },
  seatsText: {
    fontSize: 14,
    color: '#FF9800',
    fontWeight: '500',
  },
  driverContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
  },
  driverAvatar: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#E8F5E9',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 10,
  },
  driverInitial: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#008000',
  },
  driverInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
    justifyContent: 'space-between',
  },
  driverName: {
    fontSize: 14,
    color: '#333333',
  },
  ratingContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  ratingText: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#FF9800',
    marginRight: 2,
  },
  starIcon: {
    fontSize: 14,
    color: '#FF9800',
  },
  carContainer: {
    marginTop: 5,
  },
  carText: {
    fontSize: 14,
    color: '#666666',
  },
  recentSearchesContainer: {
    backgroundColor: '#FFFFFF',
    borderRadius: 15,
    padding: 20,
    marginBottom: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333333',
    marginBottom: 15,
  },
  recentSearchItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#EEEEEE',
  },
  recentSearchIcon: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: '#E8F5E9',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 10,
  },
  recentSearchIconText: {
    fontSize: 16,
  },
  recentSearchInfo: {
    flex: 1,
  },
  recentSearchRoute: {
    fontSize: 14,
    fontWeight: '500',
    color: '#333333',
    marginBottom: 2,
  },
  recentSearchDate: {
    fontSize: 12,
    color: '#666666',
  },
  popularDestinationsContainer: {
    backgroundColor: '#FFFFFF',
    borderRadius: 15,
    padding: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  popularDestinationsSection: {
    marginBottom: 15,
  },
  popularDestinationsLabel: {
    fontSize: 14,
    color: '#666666',
    marginBottom: 10,
  },
  popularDestinationsList: {
    flexDirection: 'row',
    flexWrap: 'wrap',
  },
  popularDestinationItem: {
    backgroundColor: '#E8F5E9',
    borderRadius: 20,
    paddingVertical: 8,
    paddingHorizontal: 15,
    marginRight: 10,
    marginBottom: 10,
  },
  popularDestinationText: {
    color: '#008000',
    fontSize: 14,
    fontWeight: '500',
  },
});

export default SearchRidesScreen;