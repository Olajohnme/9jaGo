import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  ActivityIndicator,
  Alert,
  Image,
} from 'react-native';
import { StatusBar } from 'expo-status-bar';
import AsyncStorage from '@react-native-async-storage/async-storage';

const CheckInScreen = ({ navigation, route }) => {
  const { bookingId } = route.params || { bookingId: null };
  
  const [booking, setBooking] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isCheckedIn, setIsCheckedIn] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  
  useEffect(() => {
    loadBookingDetails();
  }, []);
  
  const loadBookingDetails = async () => {
    try {
      setIsLoading(true);
      
      // In a real app, you would fetch the booking details from your API
      // For this demo, we'll check if we have the booking in AsyncStorage or generate mock data
      
      if (bookingId) {
        const bookingsData = await AsyncStorage.getItem('bookings');
        if (bookingsData) {
          const bookings = JSON.parse(bookingsData);
          const foundBooking = bookings.find(b => b.id === bookingId);
          
          if (foundBooking) {
            setBooking(foundBooking);
            setIsCheckedIn(foundBooking.status === 'checked-in');
            setIsLoading(false);
            return;
          }
        }
      }
      
      // If we couldn't find the booking or no bookingId was provided, create mock data
      const mockBooking = createMockBooking();
      setBooking(mockBooking);
      setIsLoading(false);
    } catch (error) {
      console.log('Error loading booking details:', error);
      setIsLoading(false);
      Alert.alert('Error', 'Failed to load booking details. Please try again.');
    }
  };
  
  const createMockBooking = () => {
    // Generate a random booking ID if none was provided
    const id = bookingId || `BK${Math.floor(Math.random() * 10000).toString().padStart(4, '0')}`;
    
    // Set departure time to a random time in the next 2 hours
    const departureTime = new Date();
    departureTime.setMinutes(departureTime.getMinutes() + Math.floor(Math.random() * 120));
    
    // Generate random driver details
    const driverFirstNames = ['Oluwaseun', 'Chijioke', 'Adebayo', 'Ngozi', 'Emeka'];
    const driverLastNames = ['Adeyemi', 'Okonkwo', 'Ojo', 'Nwachukwu', 'Okafor'];
    const driverName = `${driverFirstNames[Math.floor(Math.random() * driverFirstNames.length)]} ${driverLastNames[Math.floor(Math.random() * driverLastNames.length)]}`;
    
    // Generate random car details
    const carModels = ['Toyota Camry', 'Honda Accord', 'Toyota Corolla', 'Kia Rio', 'Hyundai Elantra'];
    const carColors = ['Black', 'White', 'Silver', 'Gray', 'Blue'];
    
    return {
      id,
      from: 'Lagos',
      to: 'Abuja',
      date: new Date().toISOString().split('T')[0],
      departureTime: departureTime.toTimeString().split(' ')[0].substring(0, 5),
      seats: [Math.floor(Math.random() * 4) + 1],
      price: Math.floor(Math.random() * 5000) + 5000,
      status: 'confirmed',
      driver: {
        name: driverName,
        phone: `+234${Math.floor(Math.random() * 10000000000).toString().padStart(10, '0')}`,
        rating: (Math.random() * 1.5 + 3.5).toFixed(1),
      },
      car: {
        model: carModels[Math.floor(Math.random() * carModels.length)],
        color: carColors[Math.floor(Math.random() * carColors.length)],
        licensePlate: `${['LAG', 'ABJ', 'PHC'][Math.floor(Math.random() * 3)]}-${Math.floor(Math.random() * 900) + 100}-${String.fromCharCode(65 + Math.floor(Math.random() * 26))}${String.fromCharCode(65 + Math.floor(Math.random() * 26))}`,
      },
    };
  };
  
  const handleCheckIn = async () => {
    if (isCheckedIn) {
      Alert.alert('Already Checked In', 'You have already checked in for this ride.');
      return;
    }
    
    setIsProcessing(true);
    
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // Update booking status
      const updatedBooking = { ...booking, status: 'checked-in' };
      setBooking(updatedBooking);
      setIsCheckedIn(true);
      
      // Update in AsyncStorage
      const bookingsData = await AsyncStorage.getItem('bookings');
      if (bookingsData) {
        const bookings = JSON.parse(bookingsData);
        const updatedBookings = bookings.map(b => 
          b.id === updatedBooking.id ? updatedBooking : b
        );
        await AsyncStorage.setItem('bookings', JSON.stringify(updatedBookings));
      }
      
      Alert.alert('Success', 'You have successfully checked in for your ride!');
    } catch (error) {
      console.log('Error checking in:', error);
      Alert.alert('Error', 'Failed to check in. Please try again.');
    } finally {
      setIsProcessing(false);
    }
  };
  
  if (isLoading) {
    return (
      <View style={styles.loadingContainer}>
        <StatusBar style="light" />
        <ActivityIndicator size="large" color="#008000" />
        <Text style={styles.loadingText}>Loading booking details...</Text>
      </View>
    );
  }
  
  return (
    <View style={styles.container}>
      <StatusBar style="light" />
      
      <View style={styles.header}>
        <TouchableOpacity
          style={styles.backButton}
          onPress={() => navigation.goBack()}
        >
          <Text style={styles.backButtonText}>←</Text>
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Check In</Text>
        <View style={styles.placeholder} />
      </View>
      
      <ScrollView contentContainerStyle={styles.scrollContent}>
        <View style={styles.bookingCard}>
          <View style={styles.bookingHeader}>
            <Text style={styles.bookingId}>Booking #{booking.id}</Text>
            <View style={[styles.statusBadge, isCheckedIn ? styles.checkedInBadge : styles.confirmedBadge]}>
              <Text style={styles.statusText}>{isCheckedIn ? 'Checked In' : 'Confirmed'}</Text>
            </View>
          </View>
          
          <View style={styles.routeContainer}>
            <View style={styles.locationContainer}>
              <View style={styles.locationDot} />
              <Text style={styles.locationText}>{booking.from}</Text>
            </View>
            
            <View style={styles.routeLine} />
            
            <View style={styles.locationContainer}>
              <View style={[styles.locationDot, styles.destinationDot]} />
              <Text style={styles.locationText}>{booking.to}</Text>
            </View>
          </View>
          
          <View style={styles.divider} />
          
          <View style={styles.detailsContainer}>
            <View style={styles.detailRow}>
              <Text style={styles.detailLabel}>Date</Text>
              <Text style={styles.detailValue}>{new Date(booking.date).toLocaleDateString('en-NG', { year: 'numeric', month: 'short', day: 'numeric' })}</Text>
            </View>
            
            <View style={styles.detailRow}>
              <Text style={styles.detailLabel}>Departure Time</Text>
              <Text style={styles.detailValue}>{booking.departureTime}</Text>
            </View>
            
            <View style={styles.detailRow}>
              <Text style={styles.detailLabel}>Seat(s)</Text>
              <Text style={styles.detailValue}>{booking.seats.join(', ')}</Text>
            </View>
            
            <View style={styles.detailRow}>
              <Text style={styles.detailLabel}>Amount Paid</Text>
              <Text style={styles.detailValue}>₦{booking.price.toLocaleString()}</Text>
            </View>
          </View>
          
          <View style={styles.divider} />
          
          <View style={styles.driverContainer}>
            <Text style={styles.sectionTitle}>Driver & Vehicle</Text>
            
            <View style={styles.driverInfo}>
              <View style={styles.driverAvatar}>
                <Text style={styles.driverInitial}>{booking.driver.name.charAt(0)}</Text>
              </View>
              
              <View style={styles.driverDetails}>
                <Text style={styles.driverName}>{booking.driver.name}</Text>
                <View style={styles.ratingContainer}>
                  <Text style={styles.ratingText}>{booking.driver.rating}</Text>
                  <Text style={styles.starIcon}>★</Text>
                </View>
              </View>
            </View>
            
            <View style={styles.carDetails}>
              <Text style={styles.carInfo}>{booking.car.model} • {booking.car.color}</Text>
              <Text style={styles.licensePlate}>{booking.car.licensePlate}</Text>
            </View>
          </View>
        </View>
        
        <View style={styles.checkInContainer}>
          <Text style={styles.checkInTitle}>
            {isCheckedIn ? 'You have checked in successfully!' : 'Ready to board?'}
          </Text>
          
          <Text style={styles.checkInDescription}>
            {isCheckedIn 
              ? 'Show this screen to your driver when boarding the vehicle.'
              : 'Check in when you arrive at the pickup location and are ready to board the vehicle.'}
          </Text>
          
          {isCheckedIn ? (
            <View style={styles.qrCodeContainer}>
              <View style={styles.qrCode}>
                <Text style={styles.qrPlaceholder}>QR Code</Text>
              </View>
              <Text style={styles.qrInstructions}>Scan this QR code or show this screen to your driver</Text>
            </View>
          ) : (
            <TouchableOpacity
              style={styles.checkInButton}
              onPress={handleCheckIn}
              disabled={isProcessing}
            >
              {isProcessing ? (
                <ActivityIndicator size="small" color="#FFFFFF" />
              ) : (
                <Text style={styles.checkInButtonText}>Check In Now</Text>
              )}
            </TouchableOpacity>
          )}
        </View>
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F5F5',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#F5F5F5',
  },
  loadingText: {
    marginTop: 10,
    fontSize: 16,
    color: '#666666',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: '#008000',
    paddingTop: 50,
    paddingBottom: 15,
    paddingHorizontal: 20,
  },
  backButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  backButtonText: {
    color: '#FFFFFF',
    fontSize: 24,
    fontWeight: 'bold',
  },
  headerTitle: {
    color: '#FFFFFF',
    fontSize: 20,
    fontWeight: 'bold',
  },
  placeholder: {
    width: 40,
  },
  scrollContent: {
    padding: 20,
    paddingBottom: 40,
  },
  bookingCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 15,
    padding: 20,
    marginBottom: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  bookingHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20,
  },
  bookingId: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333333',
  },
  statusBadge: {
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 15,
  },
  confirmedBadge: {
    backgroundColor: '#E8F5E9',
  },
  checkedInBadge: {
    backgroundColor: '#C8E6C9',
  },
  statusText: {
    fontSize: 12,
    fontWeight: 'bold',
    color: '#008000',
  },
  routeContainer: {
    marginBottom: 20,
  },
  locationContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
  },
  locationDot: {
    width: 12,
    height: 12,
    borderRadius: 6,
    backgroundColor: '#008000',
    marginRight: 10,
  },
  destinationDot: {
    backgroundColor: '#FF9800',
  },
  locationText: {
    fontSize: 16,
    color: '#333333',
  },
  routeLine: {
    width: 2,
    height: 20,
    backgroundColor: '#DDDDDD',
    marginLeft: 5,
    marginBottom: 10,
  },
  divider: {
    height: 1,
    backgroundColor: '#EEEEEE',
    marginVertical: 15,
  },
  detailsContainer: {
    marginBottom: 10,
  },
  detailRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 10,
  },
  detailLabel: {
    fontSize: 14,
    color: '#666666',
  },
  detailValue: {
    fontSize: 14,
    fontWeight: '500',
    color: '#333333',
  },
  driverContainer: {
    marginTop: 10,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333333',
    marginBottom: 15,
  },
  driverInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 15,
  },
  driverAvatar: {
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: '#E8F5E9',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 15,
  },
  driverInitial: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#008000',
  },
  driverDetails: {
    flex: 1,
  },
  driverName: {
    fontSize: 16,
    fontWeight: '500',
    color: '#333333',
    marginBottom: 5,
  },
  ratingContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  ratingText: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#FF9800',
    marginRight: 5,
  },
  starIcon: {
    fontSize: 14,
    color: '#FF9800',
  },
  carDetails: {
    backgroundColor: '#F9F9F9',
    borderRadius: 10,
    padding: 15,
  },
  carInfo: {
    fontSize: 14,
    color: '#333333',
    marginBottom: 5,
  },
  licensePlate: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333333',
  },
  checkInContainer: {
    backgroundColor: '#FFFFFF',
    borderRadius: 15,
    padding: 20,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  checkInTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333333',
    marginBottom: 10,
    textAlign: 'center',
  },
  checkInDescription: {
    fontSize: 14,
    color: '#666666',
    textAlign: 'center',
    marginBottom: 20,
  },
  checkInButton: {
    backgroundColor: '#008000',
    borderRadius: 10,
    paddingVertical: 15,
    paddingHorizontal: 30,
    width: '100%',
    alignItems: 'center',
  },
  checkInButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
  qrCodeContainer: {
    alignItems: 'center',
    width: '100%',
  },
  qrCode: {
    width: 200,
    height: 200,
    backgroundColor: '#F5F5F5',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 15,
  },
  qrPlaceholder: {
    fontSize: 16,
    color: '#666666',
  },
  qrInstructions: {
    fontSize: 14,
    color: '#666666',
    textAlign: 'center',
  },
});

export default CheckInScreen;