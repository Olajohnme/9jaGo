import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Share,
  Alert,
} from 'react-native';
import { StatusBar } from 'expo-status-bar';
import AsyncStorage from '@react-native-async-storage/async-storage';

const BookingConfirmationScreen = ({ route, navigation }) => {
  const { ride, selectedSeats, totalAmount, bookingId } = route.params;
  const [countdown, setCountdown] = useState(null);
  
  useEffect(() => {
    // Calculate time remaining until departure
    const calculateTimeRemaining = () => {
      const [day, month, year] = ride.date.split('-').map(Number);
      const [time, period] = ride.time.split(' ');
      const [hours, minutes] = time.split(':').map(Number);
      
      // Convert to 24-hour format
      let hour24 = hours;
      if (period === 'PM' && hours !== 12) {
        hour24 += 12;
      } else if (period === 'AM' && hours === 12) {
        hour24 = 0;
      }
      
      // Create departure date object
      const departureDate = new Date(year, month - 1, day, hour24, minutes);
      const now = new Date();
      
      // Calculate difference in milliseconds
      const diff = departureDate - now;
      
      if (diff <= 0) {
        // Departure time has passed
        return { days: 0, hours: 0, minutes: 0 };
      }
      
      // Convert to days, hours, minutes
      const days = Math.floor(diff / (1000 * 60 * 60 * 24));
      const remainingHours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
      const remainingMinutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
      
      return { days, hours: remainingHours, minutes: remainingMinutes };
    };
    
    // Set initial countdown
    setCountdown(calculateTimeRemaining());
    
    // Update countdown every minute
    const intervalId = setInterval(() => {
      const timeRemaining = calculateTimeRemaining();
      setCountdown(timeRemaining);
      
      // Stop interval if departure time has passed
      if (timeRemaining.days === 0 && timeRemaining.hours === 0 && timeRemaining.minutes === 0) {
        clearInterval(intervalId);
      }
    }, 60000); // Update every minute
    
    return () => clearInterval(intervalId);
  }, [ride.date, ride.time]);
  
  const handleShareBooking = async () => {
    try {
      const message = `I've booked a ride with 9jaRide!\n\nFrom: ${ride.from}\nTo: ${ride.to}\nDate: ${ride.date}\nTime: ${ride.time}\nBooking ID: ${bookingId}\n\nDownload the 9jaRide app to book your next journey!`;
      
      await Share.share({
        message,
        title: '9jaRide Booking',
      });
    } catch (error) {
      Alert.alert('Error', 'Could not share booking details.');
    }
  };
  
  const handleViewTicket = () => {
    // Navigate to ticket screen
    navigation.navigate('Ticket', {
      ride,
      selectedSeats,
      totalAmount,
      bookingId,
    });
  };
  
  const handleGoToHome = () => {
    // Navigate back to home screen
    navigation.navigate('PassengerHome');
  };
  
  return (
    <View style={styles.container}>
      <StatusBar style="light" />
      
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Booking Confirmed</Text>
      </View>
      
      <ScrollView contentContainerStyle={styles.scrollContent}>
        <View style={styles.successContainer}>
          <View style={styles.successIcon}>
            <Text style={styles.successIconText}>✓</Text>
          </View>
          <Text style={styles.successTitle}>Booking Successful!</Text>
          <Text style={styles.successMessage}>
            Your ride has been booked successfully. You can check in when you board the vehicle.
          </Text>
        </View>
        
        <View style={styles.bookingDetailsCard}>
          <Text style={styles.sectionTitle}>Booking Details</Text>
          
          <View style={styles.bookingDetail}>
            <Text style={styles.bookingDetailLabel}>Booking ID:</Text>
            <Text style={styles.bookingDetailValue}>{bookingId}</Text>
          </View>
          
          <View style={styles.bookingDetail}>
            <Text style={styles.bookingDetailLabel}>Route:</Text>
            <Text style={styles.bookingDetailValue}>{ride.from} → {ride.to}</Text>
          </View>
          
          <View style={styles.bookingDetail}>
            <Text style={styles.bookingDetailLabel}>Date & Time:</Text>
            <Text style={styles.bookingDetailValue}>{ride.date}, {ride.time}</Text>
          </View>
          
          <View style={styles.bookingDetail}>
            <Text style={styles.bookingDetailLabel}>Seats:</Text>
            <Text style={styles.bookingDetailValue}>{selectedSeats.join(', ')}</Text>
          </View>
          
          <View style={styles.bookingDetail}>
            <Text style={styles.bookingDetailLabel}>Amount Paid:</Text>
            <Text style={styles.bookingDetailValue}>₦{totalAmount.toLocaleString()}</Text>
          </View>
        </View>
        
        <View style={styles.driverCard}>
          <Text style={styles.sectionTitle}>Driver Information</Text>
          
          <View style={styles.driverInfo}>
            <View style={styles.driverAvatar}>
              <Text style={styles.driverInitial}>{ride.driver.charAt(0)}</Text>
            </View>
            
            <View style={styles.driverDetails}>
              <Text style={styles.driverName}>{ride.driver}</Text>
              <Text style={styles.carInfo}>{ride.carModel}, {ride.carColor}</Text>
            </View>
          </View>
        </View>
        
        {countdown && (
          <View style={styles.countdownCard}>
            <Text style={styles.sectionTitle}>Departure In</Text>
            
            <View style={styles.countdownContainer}>
              <View style={styles.countdownItem}>
                <Text style={styles.countdownValue}>{countdown.days}</Text>
                <Text style={styles.countdownLabel}>Days</Text>
              </View>
              
              <View style={styles.countdownItem}>
                <Text style={styles.countdownValue}>{countdown.hours}</Text>
                <Text style={styles.countdownLabel}>Hours</Text>
              </View>
              
              <View style={styles.countdownItem}>
                <Text style={styles.countdownValue}>{countdown.minutes}</Text>
                <Text style={styles.countdownLabel}>Minutes</Text>
              </View>
            </View>
          </View>
        )}
        
        <View style={styles.actionsContainer}>
          <TouchableOpacity
            style={styles.actionButton}
            onPress={handleViewTicket}
          >
            <Text style={styles.actionButtonText}>View Ticket</Text>
          </TouchableOpacity>
          
          <TouchableOpacity
            style={[styles.actionButton, styles.shareButton]}
            onPress={handleShareBooking}
          >
            <Text style={styles.shareButtonText}>Share Booking</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
      
      <View style={styles.footer}>
        <TouchableOpacity
          style={styles.homeButton}
          onPress={handleGoToHome}
        >
          <Text style={styles.homeButtonText}>Go to Home</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F5F5',
  },
  header: {
    backgroundColor: '#008000',
    paddingTop: 50,
    paddingBottom: 15,
    paddingHorizontal: 20,
    alignItems: 'center',
  },
  headerTitle: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: 'bold',
  },
  scrollContent: {
    padding: 20,
  },
  successContainer: {
    alignItems: 'center',
    marginBottom: 20,
  },
  successIcon: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: '#008000',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 15,
  },
  successIconText: {
    color: '#FFFFFF',
    fontSize: 40,
    fontWeight: 'bold',
  },
  successTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#333333',
    marginBottom: 10,
  },
  successMessage: {
    fontSize: 14,
    color: '#666666',
    textAlign: 'center',
    lineHeight: 20,
  },
  bookingDetailsCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 15,
    padding: 20,
    marginBottom: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333333',
    marginBottom: 15,
  },
  bookingDetail: {
    flexDirection: 'row',
    marginBottom: 10,
  },
  bookingDetailLabel: {
    fontSize: 14,
    color: '#666666',
    width: 100,
  },
  bookingDetailValue: {
    fontSize: 14,
    color: '#333333',
    fontWeight: '500',
    flex: 1,
  },
  driverCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 15,
    padding: 20,
    marginBottom: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  driverInfo: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  driverAvatar: {
    width: 60,
    height: 60,
    borderRadius: 30,
    backgroundColor: '#E8F5E9',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 15,
  },
  driverInitial: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#008000',
  },
  driverDetails: {
    flex: 1,
  },
  driverName: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333333',
    marginBottom: 5,
  },
  carInfo: {
    fontSize: 14,
    color: '#666666',
  },
  countdownCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 15,
    padding: 20,
    marginBottom: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  countdownContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
  },
  countdownItem: {
    alignItems: 'center',
  },
  countdownValue: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#008000',
    marginBottom: 5,
  },
  countdownLabel: {
    fontSize: 12,
    color: '#666666',
  },
  actionsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 20,
  },
  actionButton: {
    flex: 1,
    backgroundColor: '#008000',
    borderRadius: 10,
    padding: 15,
    alignItems: 'center',
    marginRight: 10,
  },
  actionButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
  shareButton: {
    backgroundColor: '#FFFFFF',
    borderWidth: 1,
    borderColor: '#008000',
    marginRight: 0,
    marginLeft: 10,
  },
  shareButtonText: {
    color: '#008000',
    fontSize: 16,
    fontWeight: 'bold',
  },
  footer: {
    backgroundColor: '#FFFFFF',
    padding: 20,
    borderTopWidth: 1,
    borderTopColor: '#EEEEEE',
  },
  homeButton: {
    backgroundColor: '#008000',
    borderRadius: 10,
    padding: 15,
    alignItems: 'center',
  },
  homeButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
});

export default BookingConfirmationScreen;