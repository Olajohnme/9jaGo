import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  TextInput,
  Alert,
  ActivityIndicator,
  Image,
} from 'react-native';
import { StatusBar } from 'expo-status-bar';
import AsyncStorage from '@react-native-async-storage/async-storage';

const PaymentScreen = ({ route, navigation }) => {
  const { ride, selectedSeats, totalAmount } = route.params;
  
  const [paymentMethod, setPaymentMethod] = useState('card');
  const [cardNumber, setCardNumber] = useState('');
  const [expiryDate, setExpiryDate] = useState('');
  const [cvv, setCvv] = useState('');
  const [cardholderName, setCardholderName] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [email, setEmail] = useState('');
  
  useEffect(() => {
    // Load user email from AsyncStorage
    const loadUserEmail = async () => {
      try {
        const userEmail = await AsyncStorage.getItem('userEmail');
        if (userEmail) {
          setEmail(userEmail);
        }
      } catch (error) {
        console.log('Error loading user email:', error);
      }
    };
    
    loadUserEmail();
  }, []);
  
  const formatCardNumber = (text) => {
    // Remove all non-digit characters
    const cleaned = text.replace(/\D/g, '');
    
    // Format with spaces after every 4 digits
    const formatted = cleaned.replace(/(.{4})/g, '$1 ').trim();
    
    // Limit to 19 characters (16 digits + 3 spaces)
    return formatted.slice(0, 19);
  };
  
  const formatExpiryDate = (text) => {
    // Remove all non-digit characters
    const cleaned = text.replace(/\D/g, '');
    
    // Format as MM/YY
    if (cleaned.length > 2) {
      return `${cleaned.slice(0, 2)}/${cleaned.slice(2, 4)}`;
    }
    
    return cleaned;
  };
  
  const handleCardNumberChange = (text) => {
    setCardNumber(formatCardNumber(text));
  };
  
  const handleExpiryDateChange = (text) => {
    setExpiryDate(formatExpiryDate(text));
  };
  
  const validateCardDetails = () => {
    if (cardNumber.replace(/\s/g, '').length !== 16) {
      Alert.alert('Invalid Card Number', 'Please enter a valid 16-digit card number.');
      return false;
    }
    
    if (expiryDate.length !== 5) {
      Alert.alert('Invalid Expiry Date', 'Please enter a valid expiry date in MM/YY format.');
      return false;
    }
    
    const month = parseInt(expiryDate.split('/')[0], 10);
    if (month < 1 || month > 12) {
      Alert.alert('Invalid Expiry Date', 'Month must be between 01 and 12.');
      return false;
    }
    
    if (cvv.length !== 3) {
      Alert.alert('Invalid CVV', 'Please enter a valid 3-digit CVV code.');
      return false;
    }
    
    if (!cardholderName.trim()) {
      Alert.alert('Invalid Name', 'Please enter the cardholder name.');
      return false;
    }
    
    return true;
  };
  
  const handlePayment = () => {
    if (paymentMethod === 'card' && !validateCardDetails()) {
      return;
    }
    
    // Simulate payment processing
    setIsLoading(true);
    
    // Mock Paystack API call
    setTimeout(() => {
      setIsLoading(false);
      
      // Simulate successful payment
      Alert.alert(
        'Payment Successful',
        'Your booking has been confirmed!',
        [
          {
            text: 'OK',
            onPress: () => {
              // Save booking to AsyncStorage
              saveBooking();
              
              // Navigate to booking confirmation screen
              navigation.navigate('BookingConfirmation', {
                ride,
                selectedSeats,
                totalAmount,
                bookingId: generateBookingId(),
              });
            },
          },
        ]
      );
    }, 2000);
  };
  
  const generateBookingId = () => {
    // Generate a random booking ID
    return 'BK' + Math.floor(100000 + Math.random() * 900000);
  };
  
  const saveBooking = async () => {
    try {
      // Get existing bookings
      const existingBookingsJson = await AsyncStorage.getItem('userBookings');
      const existingBookings = existingBookingsJson ? JSON.parse(existingBookingsJson) : [];
      
      // Create new booking object
      const newBooking = {
        id: generateBookingId(),
        ride: {
          from: ride.from,
          to: ride.to,
          date: ride.date,
          time: ride.time,
          driver: ride.driver,
          carModel: ride.carModel,
          carColor: ride.carColor,
        },
        seats: selectedSeats,
        amount: totalAmount,
        status: 'confirmed',
        bookingDate: new Date().toISOString(),
        checkedIn: false,
      };
      
      // Add new booking to existing bookings
      const updatedBookings = [newBooking, ...existingBookings];
      
      // Save updated bookings to AsyncStorage
      await AsyncStorage.setItem('userBookings', JSON.stringify(updatedBookings));
    } catch (error) {
      console.log('Error saving booking:', error);
    }
  };
  
  const formatTotalAmount = () => {
    return `₦${totalAmount.toLocaleString()}`;
  };
  
  return (
    <View style={styles.container}>
      <StatusBar style="light" />
      
      <View style={styles.header}>
        <TouchableOpacity
          style={styles.backButton}
          onPress={() => navigation.goBack()}
        >
          <Text style={styles.backButtonText}>←</Text>
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Payment</Text>
        <View style={styles.placeholder} />
      </View>
      
      <ScrollView contentContainerStyle={styles.scrollContent}>
        <View style={styles.orderSummary}>
          <Text style={styles.sectionTitle}>Order Summary</Text>
          
          <View style={styles.summaryItem}>
            <Text style={styles.summaryLabel}>Route:</Text>
            <Text style={styles.summaryValue}>{ride.from} → {ride.to}</Text>
          </View>
          
          <View style={styles.summaryItem}>
            <Text style={styles.summaryLabel}>Date & Time:</Text>
            <Text style={styles.summaryValue}>{ride.date}, {ride.time}</Text>
          </View>
          
          <View style={styles.summaryItem}>
            <Text style={styles.summaryLabel}>Seats:</Text>
            <Text style={styles.summaryValue}>{selectedSeats.join(', ')}</Text>
          </View>
          
          <View style={styles.summaryItem}>
            <Text style={styles.summaryLabel}>Price per seat:</Text>
            <Text style={styles.summaryValue}>{ride.price}</Text>
          </View>
          
          <View style={[styles.summaryItem, styles.totalItem]}>
            <Text style={styles.totalLabel}>Total Amount:</Text>
            <Text style={styles.totalValue}>{formatTotalAmount()}</Text>
          </View>
        </View>
        
        <View style={styles.paymentMethodsContainer}>
          <Text style={styles.sectionTitle}>Payment Method</Text>
          
          <View style={styles.paymentMethods}>
            <TouchableOpacity
              style={[
                styles.paymentMethodOption,
                paymentMethod === 'card' && styles.selectedPaymentMethod,
              ]}
              onPress={() => setPaymentMethod('card')}
            >
              <View style={styles.paymentMethodIcon}>
                <Text style={styles.paymentMethodIconText}>💳</Text>
              </View>
              <Text style={styles.paymentMethodText}>Card Payment</Text>
            </TouchableOpacity>
            
            <TouchableOpacity
              style={[
                styles.paymentMethodOption,
                paymentMethod === 'bank' && styles.selectedPaymentMethod,
              ]}
              onPress={() => setPaymentMethod('bank')}
            >
              <View style={styles.paymentMethodIcon}>
                <Text style={styles.paymentMethodIconText}>🏦</Text>
              </View>
              <Text style={styles.paymentMethodText}>Bank Transfer</Text>
            </TouchableOpacity>
          </View>
        </View>
        
        {paymentMethod === 'card' && (
          <View style={styles.cardDetailsContainer}>
            <Text style={styles.sectionTitle}>Card Details</Text>
            
            <View style={styles.paystackBadge}>
              <Text style={styles.securedByText}>Secured by</Text>
              <Text style={styles.paystackText}>Paystack</Text>
            </View>
            
            <View style={styles.formGroup}>
              <Text style={styles.inputLabel}>Card Number</Text>
              <TextInput
                style={styles.input}
                placeholder="1234 5678 9012 3456"
                keyboardType="numeric"
                value={cardNumber}
                onChangeText={handleCardNumberChange}
                maxLength={19}
              />
            </View>
            
            <View style={styles.formRow}>
              <View style={[styles.formGroup, styles.halfWidth]}>
                <Text style={styles.inputLabel}>Expiry Date</Text>
                <TextInput
                  style={styles.input}
                  placeholder="MM/YY"
                  keyboardType="numeric"
                  value={expiryDate}
                  onChangeText={handleExpiryDateChange}
                  maxLength={5}
                />
              </View>
              
              <View style={[styles.formGroup, styles.halfWidth]}>
                <Text style={styles.inputLabel}>CVV</Text>
                <TextInput
                  style={styles.input}
                  placeholder="123"
                  keyboardType="numeric"
                  value={cvv}
                  onChangeText={setCvv}
                  maxLength={3}
                  secureTextEntry
                />
              </View>
            </View>
            
            <View style={styles.formGroup}>
              <Text style={styles.inputLabel}>Cardholder Name</Text>
              <TextInput
                style={styles.input}
                placeholder="John Doe"
                value={cardholderName}
                onChangeText={setCardholderName}
              />
            </View>
            
            <View style={styles.formGroup}>
              <Text style={styles.inputLabel}>Email</Text>
              <TextInput
                style={styles.input}
                placeholder="email@example.com"
                keyboardType="email-address"
                value={email}
                onChangeText={setEmail}
                editable={!email} // Make it non-editable if loaded from AsyncStorage
              />
            </View>
          </View>
        )}
        
        {paymentMethod === 'bank' && (
          <View style={styles.bankDetailsContainer}>
            <Text style={styles.sectionTitle}>Bank Transfer Details</Text>
            
            <View style={styles.bankInstructions}>
              <Text style={styles.bankInstructionText}>
                Please transfer the exact amount to the following account:
              </Text>
              
              <View style={styles.bankDetail}>
                <Text style={styles.bankDetailLabel}>Bank Name:</Text>
                <Text style={styles.bankDetailValue}>First Bank of Nigeria</Text>
              </View>
              
              <View style={styles.bankDetail}>
                <Text style={styles.bankDetailLabel}>Account Name:</Text>
                <Text style={styles.bankDetailValue}>9jaRide Transport Ltd</Text>
              </View>
              
              <View style={styles.bankDetail}>
                <Text style={styles.bankDetailLabel}>Account Number:</Text>
                <Text style={styles.bankDetailValue}>0123456789</Text>
              </View>
              
              <View style={styles.bankDetail}>
                <Text style={styles.bankDetailLabel}>Amount:</Text>
                <Text style={styles.bankDetailValue}>{formatTotalAmount()}</Text>
              </View>
              
              <Text style={styles.bankInstructionText}>
                After making the transfer, please click the "Confirm Payment" button below.
                Our team will verify your payment and confirm your booking.
              </Text>
            </View>
          </View>
        )}
      </ScrollView>
      
      <View style={styles.footer}>
        <TouchableOpacity
          style={styles.payButton}
          onPress={handlePayment}
          disabled={isLoading}
        >
          {isLoading ? (
            <ActivityIndicator size="small" color="#FFFFFF" />
          ) : (
            <Text style={styles.payButtonText}>
              {paymentMethod === 'card' ? 'Pay' : 'Confirm Payment'} {formatTotalAmount()}
            </Text>
          )}
        </TouchableOpacity>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F5F5',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: '#008000',
    paddingTop: 50,
    paddingBottom: 15,
    paddingHorizontal: 20,
  },
  backButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  backButtonText: {
    color: '#FFFFFF',
    fontSize: 24,
    fontWeight: 'bold',
  },
  headerTitle: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: 'bold',
  },
  placeholder: {
    width: 40,
  },
  scrollContent: {
    padding: 20,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333333',
    marginBottom: 15,
  },
  orderSummary: {
    backgroundColor: '#FFFFFF',
    borderRadius: 15,
    padding: 20,
    marginBottom: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  summaryItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 10,
  },
  summaryLabel: {
    fontSize: 14,
    color: '#666666',
  },
  summaryValue: {
    fontSize: 14,
    color: '#333333',
    fontWeight: '500',
  },
  totalItem: {
    marginTop: 10,
    paddingTop: 10,
    borderTopWidth: 1,
    borderTopColor: '#EEEEEE',
  },
  totalLabel: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333333',
  },
  totalValue: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#008000',
  },
  paymentMethodsContainer: {
    backgroundColor: '#FFFFFF',
    borderRadius: 15,
    padding: 20,
    marginBottom: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  paymentMethods: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  paymentMethodOption: {
    flex: 1,
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 15,
    borderWidth: 1,
    borderColor: '#EEEEEE',
    borderRadius: 10,
    marginHorizontal: 5,
  },
  selectedPaymentMethod: {
    borderColor: '#008000',
    backgroundColor: '#E8F5E9',
  },
  paymentMethodIcon: {
    marginBottom: 10,
  },
  paymentMethodIconText: {
    fontSize: 24,
  },
  paymentMethodText: {
    fontSize: 14,
    color: '#333333',
    textAlign: 'center',
  },
  cardDetailsContainer: {
    backgroundColor: '#FFFFFF',
    borderRadius: 15,
    padding: 20,
    marginBottom: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  paystackBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    alignSelf: 'flex-end',
    marginBottom: 15,
  },
  securedByText: {
    fontSize: 12,
    color: '#666666',
    marginRight: 5,
  },
  paystackText: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#008000',
  },
  formGroup: {
    marginBottom: 15,
  },
  formRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  halfWidth: {
    width: '48%',
  },
  inputLabel: {
    fontSize: 14,
    color: '#666666',
    marginBottom: 5,
  },
  input: {
    backgroundColor: '#F5F5F5',
    borderRadius: 10,
    padding: 15,
    fontSize: 16,
    color: '#333333',
    borderWidth: 1,
    borderColor: '#EEEEEE',
  },
  bankDetailsContainer: {
    backgroundColor: '#FFFFFF',
    borderRadius: 15,
    padding: 20,
    marginBottom: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  bankInstructions: {
    backgroundColor: '#F5F5F5',
    borderRadius: 10,
    padding: 15,
  },
  bankInstructionText: {
    fontSize: 14,
    color: '#333333',
    marginBottom: 15,
    lineHeight: 20,
  },
  bankDetail: {
    flexDirection: 'row',
    marginBottom: 10,
  },
  bankDetailLabel: {
    fontSize: 14,
    color: '#666666',
    width: 120,
  },
  bankDetailValue: {
    fontSize: 14,
    color: '#333333',
    fontWeight: '500',
    flex: 1,
  },
  footer: {
    backgroundColor: '#FFFFFF',
    padding: 20,
    borderTopWidth: 1,
    borderTopColor: '#EEEEEE',
  },
  payButton: {
    backgroundColor: '#008000',
    borderRadius: 10,
    padding: 15,
    alignItems: 'center',
  },
  payButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
});

export default PaymentScreen;