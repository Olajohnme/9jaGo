import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Share,
  Alert,
  Linking,
} from 'react-native';
import { StatusBar } from 'expo-status-bar';
import AsyncStorage from '@react-native-async-storage/async-storage';

const BookingDetailsScreen = ({ route, navigation }) => {
  const { booking } = route.params;
  const [timeLeft, setTimeLeft] = useState('');
  const [countdown, setCountdown] = useState(null);
  
  useEffect(() => {
    // Calculate time left for upcoming trips
    if (isUpcoming()) {
      calculateTimeLeft();
      const timer = setInterval(calculateTimeLeft, 60000); // Update every minute
      setCountdown(timer);
    }
    
    return () => {
      if (countdown) {
        clearInterval(countdown);
      }
    };
  }, []);
  
  const isUpcoming = () => {
    const departureDate = new Date(booking.departureDate);
    const currentDate = new Date();
    return departureDate > currentDate && booking.status !== 'cancelled';
  };
  
  const calculateTimeLeft = () => {
    const departureDate = new Date(booking.departureDate);
    const currentDate = new Date();
    
    if (departureDate <= currentDate) {
      setTimeLeft('Departed');
      if (countdown) {
        clearInterval(countdown);
      }
      return;
    }
    
    const diffTime = Math.abs(departureDate - currentDate);
    const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
    const diffHours = Math.floor((diffTime % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    const diffMinutes = Math.floor((diffTime % (1000 * 60 * 60)) / (1000 * 60));
    
    let timeLeftStr = '';
    if (diffDays > 0) {
      timeLeftStr += `${diffDays} day${diffDays > 1 ? 's' : ''} `;
    }
    if (diffHours > 0 || diffDays > 0) {
      timeLeftStr += `${diffHours} hour${diffHours > 1 ? 's' : ''} `;
    }
    timeLeftStr += `${diffMinutes} minute${diffMinutes > 1 ? 's' : ''}`;
    
    setTimeLeft(timeLeftStr);
  };
  
  const handleShareBooking = async () => {
    try {
      const departureDate = new Date(booking.departureDate);
      const formattedDate = departureDate.toLocaleDateString('en-NG', {
        weekday: 'short',
        day: 'numeric',
        month: 'short',
        year: 'numeric',
      });
      
      const message = `I'm traveling from ${booking.from} to ${booking.to} on ${formattedDate} at ${booking.departureTime} with 9jaRide. My booking reference is ${booking.bookingId}.`;
      
      await Share.share({
        message,
        title: '9jaRide Booking',
      });
    } catch (error) {
      console.log('Error sharing booking:', error);
      Alert.alert('Error', 'Failed to share booking. Please try again.');
    }
  };
  
  const handleContactDriver = () => {
    // In a real app, this would open a chat with the driver or make a call
    Alert.alert(
      'Contact Driver',
      'Would you like to call or message the driver?',
      [
        {
          text: 'Cancel',
          style: 'cancel',
        },
        {
          text: 'Call',
          onPress: () => {
            // Simulate a phone call
            Linking.openURL(`tel:+2348012345678`);
          },
        },
        {
          text: 'Message',
          onPress: () => {
            // Simulate sending a message
            Linking.openURL(`sms:+2348012345678`);
          },
        },
      ]
    );
  };
  
  const handleCancelBooking = () => {
    Alert.alert(
      'Cancel Booking',
      'Are you sure you want to cancel this booking?',
      [
        {
          text: 'No',
          style: 'cancel',
        },
        {
          text: 'Yes',
          onPress: async () => {
            try {
              // Update booking status
              const bookingsData = await AsyncStorage.getItem('userBookings');
              
              if (bookingsData) {
                const bookings = JSON.parse(bookingsData);
                const updatedBookings = bookings.map(item => {
                  if (item.id === booking.id) {
                    return { ...item, status: 'cancelled' };
                  }
                  return item;
                });
                
                await AsyncStorage.setItem('userBookings', JSON.stringify(updatedBookings));
                
                // Navigate back to booking history with refresh flag
                navigation.navigate('BookingHistory', { refresh: true });
                
                Alert.alert('Success', 'Booking has been cancelled successfully!');
              }
            } catch (error) {
              console.log('Error cancelling booking:', error);
              Alert.alert('Error', 'Failed to cancel booking. Please try again.');
            }
          },
        },
      ],
      { cancelable: false }
    );
  };
  
  const departureDate = new Date(booking.departureDate);
  const formattedDate = departureDate.toLocaleDateString('en-NG', {
    weekday: 'short',
    day: 'numeric',
    month: 'short',
    year: 'numeric',
  });
  
  const bookingDate = new Date(booking.bookingDate);
  const formattedBookingDate = bookingDate.toLocaleDateString('en-NG', {
    day: 'numeric',
    month: 'short',
    year: 'numeric',
  });
  
  return (
    <View style={styles.container}>
      <StatusBar style="light" />
      
      <View style={styles.header}>
        <TouchableOpacity
          style={styles.backButton}
          onPress={() => navigation.goBack()}
        >
          <Text style={styles.backButtonText}>←</Text>
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Booking Details</Text>
        <TouchableOpacity
          style={styles.shareButton}
          onPress={handleShareBooking}
        >
          <Text style={styles.shareButtonText}>Share</Text>
        </TouchableOpacity>
      </View>
      
      <ScrollView contentContainerStyle={styles.scrollContent}>
        <View style={styles.statusContainer}>
          <View style={[
            styles.statusBadge,
            booking.status === 'confirmed' ? styles.confirmedBadge :
            booking.status === 'completed' ? styles.completedBadge :
            styles.cancelledBadge
          ]}>
            <Text style={[
              styles.statusText,
              booking.status === 'confirmed' ? styles.confirmedText :
              booking.status === 'completed' ? styles.completedText :
              styles.cancelledText
            ]}>
              {booking.status === 'confirmed' ? 'Confirmed' :
               booking.status === 'completed' ? 'Completed' :
               'Cancelled'}
            </Text>
          </View>
          
          {isUpcoming() && (
            <View style={styles.countdownContainer}>
              <Text style={styles.countdownLabel}>Departure in:</Text>
              <Text style={styles.countdownValue}>{timeLeft}</Text>
            </View>
          )}
        </View>
        
        <View style={styles.bookingCard}>
          <View style={styles.bookingHeader}>
            <Text style={styles.bookingIdText}>Booking ID: {booking.bookingId}</Text>
            <Text style={styles.bookingDateText}>Booked on {formattedBookingDate}</Text>
          </View>
          
          <View style={styles.tripDetails}>
            <View style={styles.locationContainer}>
              <View style={styles.locationPoint} />
              <Text style={styles.locationText}>{booking.from}</Text>
            </View>
            
            <View style={styles.locationDivider} />
            
            <View style={styles.locationContainer}>
              <View style={[styles.locationPoint, styles.destinationPoint]} />
              <Text style={styles.locationText}>{booking.to}</Text>
            </View>
          </View>
          
          <View style={styles.detailsGrid}>
            <View style={styles.detailItem}>
              <Text style={styles.detailLabel}>Date</Text>
              <Text style={styles.detailValue}>{formattedDate}</Text>
            </View>
            
            <View style={styles.detailItem}>
              <Text style={styles.detailLabel}>Time</Text>
              <Text style={styles.detailValue}>{booking.departureTime}</Text>
            </View>
            
            <View style={styles.detailItem}>
              <Text style={styles.detailLabel}>Seat(s)</Text>
              <Text style={styles.detailValue}>{booking.seats.join(', ')}</Text>
            </View>
            
            <View style={styles.detailItem}>
              <Text style={styles.detailLabel}>Price</Text>
              <Text style={styles.detailValue}>₦{booking.price.toLocaleString()}</Text>
            </View>
          </View>
        </View>
        
        <View style={styles.driverCard}>
          <Text style={styles.sectionTitle}>Driver & Vehicle</Text>
          
          <View style={styles.driverInfo}>
            <View style={styles.driverAvatar}>
              <Text style={styles.driverInitial}>{booking.driverName.charAt(0)}</Text>
            </View>
            
            <View style={styles.driverDetails}>
              <Text style={styles.driverName}>{booking.driverName}</Text>
              <Text style={styles.carDetails}>{booking.carModel} • {booking.carColor}</Text>
            </View>
            
            {isUpcoming() && (
              <TouchableOpacity
                style={styles.contactButton}
                onPress={handleContactDriver}
              >
                <Text style={styles.contactButtonText}>Contact</Text>
              </TouchableOpacity>
            )}
          </View>
        </View>
        
        <View style={styles.paymentCard}>
          <Text style={styles.sectionTitle}>Payment Information</Text>
          
          <View style={styles.paymentDetails}>
            <View style={styles.paymentRow}>
              <Text style={styles.paymentLabel}>Payment Method</Text>
              <Text style={styles.paymentValue}>{booking.paymentMethod}</Text>
            </View>
            
            <View style={styles.paymentRow}>
              <Text style={styles.paymentLabel}>Subtotal</Text>
              <Text style={styles.paymentValue}>₦{booking.price.toLocaleString()}</Text>
            </View>
            
            <View style={styles.paymentRow}>
              <Text style={styles.paymentLabel}>Service Fee</Text>
              <Text style={styles.paymentValue}>₦{Math.floor(booking.price * 0.05).toLocaleString()}</Text>
            </View>
            
            <View style={[styles.paymentRow, styles.totalRow]}>
              <Text style={styles.totalLabel}>Total</Text>
              <Text style={styles.totalValue}>₦{Math.floor(booking.price * 1.05).toLocaleString()}</Text>
            </View>
          </View>
        </View>
        
        {isUpcoming() && (
          <View style={styles.actionsContainer}>
            <TouchableOpacity
              style={styles.cancelButton}
              onPress={handleCancelBooking}
            >
              <Text style={styles.cancelButtonText}>Cancel Booking</Text>
            </TouchableOpacity>
          </View>
        )}
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F5F5',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: '#008000',
    paddingTop: 50,
    paddingBottom: 15,
    paddingHorizontal: 20,
  },
  backButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  backButtonText: {
    color: '#FFFFFF',
    fontSize: 24,
    fontWeight: 'bold',
  },
  headerTitle: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: 'bold',
  },
  shareButton: {
    paddingHorizontal: 15,
    paddingVertical: 8,
    borderRadius: 20,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
  },
  shareButtonText: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: '500',
  },
  scrollContent: {
    padding: 20,
    paddingBottom: 40,
  },
  statusContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20,
  },
  statusBadge: {
    paddingHorizontal: 15,
    paddingVertical: 8,
    borderRadius: 20,
  },
  confirmedBadge: {
    backgroundColor: '#E8F5E9',
  },
  completedBadge: {
    backgroundColor: '#E3F2FD',
  },
  cancelledBadge: {
    backgroundColor: '#FFEBEE',
  },
  statusText: {
    fontSize: 14,
    fontWeight: '500',
  },
  confirmedText: {
    color: '#008000',
  },
  completedText: {
    color: '#1976D2',
  },
  cancelledText: {
    color: '#D32F2F',
  },
  countdownContainer: {
    alignItems: 'flex-end',
  },
  countdownLabel: {
    fontSize: 12,
    color: '#666666',
    marginBottom: 2,
  },
  countdownValue: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#008000',
  },
  bookingCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 15,
    padding: 20,
    marginBottom: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  bookingHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 20,
    paddingBottom: 15,
    borderBottomWidth: 1,
    borderBottomColor: '#F0F0F0',
  },
  bookingIdText: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#333333',
  },
  bookingDateText: {
    fontSize: 12,
    color: '#666666',
  },
  tripDetails: {
    marginBottom: 20,
  },
  locationContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
  },
  locationPoint: {
    width: 12,
    height: 12,
    borderRadius: 6,
    backgroundColor: '#008000',
    marginRight: 15,
  },
  destinationPoint: {
    backgroundColor: '#FF9800',
  },
  locationText: {
    fontSize: 16,
    fontWeight: '500',
    color: '#333333',
  },
  locationDivider: {
    width: 1,
    height: 30,
    backgroundColor: '#CCCCCC',
    marginLeft: 6,
    marginBottom: 10,
  },
  detailsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    marginHorizontal: -10,
  },
  detailItem: {
    width: '50%',
    paddingHorizontal: 10,
    marginBottom: 15,
  },
  detailLabel: {
    fontSize: 12,
    color: '#999999',
    marginBottom: 5,
  },
  detailValue: {
    fontSize: 16,
    fontWeight: '500',
    color: '#333333',
  },
  driverCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 15,
    padding: 20,
    marginBottom: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333333',
    marginBottom: 15,
  },
  driverInfo: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  driverAvatar: {
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: '#E8F5E9',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 15,
  },
  driverInitial: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#008000',
  },
  driverDetails: {
    flex: 1,
  },
  driverName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333333',
    marginBottom: 5,
  },
  carDetails: {
    fontSize: 14,
    color: '#666666',
  },
  contactButton: {
    backgroundColor: '#008000',
    borderRadius: 8,
    paddingVertical: 8,
    paddingHorizontal: 15,
  },
  contactButtonText: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: '500',
  },
  paymentCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 15,
    padding: 20,
    marginBottom: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  paymentDetails: {
    marginBottom: 10,
  },
  paymentRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 10,
  },
  paymentLabel: {
    fontSize: 14,
    color: '#666666',
  },
  paymentValue: {
    fontSize: 14,
    fontWeight: '500',
    color: '#333333',
  },
  totalRow: {
    borderTopWidth: 1,
    borderTopColor: '#F0F0F0',
    paddingTop: 10,
    marginTop: 5,
  },
  totalLabel: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333333',
  },
  totalValue: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#008000',
  },
  actionsContainer: {
    marginTop: 10,
  },
  cancelButton: {
    backgroundColor: '#FFEBEE',
    borderRadius: 10,
    padding: 15,
    alignItems: 'center',
  },
  cancelButtonText: {
    color: '#D32F2F',
    fontSize: 16,
    fontWeight: '500',
  },
});

export default BookingDetailsScreen;