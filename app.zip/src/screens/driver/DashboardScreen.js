import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  FlatList,
  Alert,
  Modal,
  TextInput,
  ActivityIndicator,
} from 'react-native';
import { StatusBar } from 'expo-status-bar';
import AsyncStorage from '@react-native-async-storage/async-storage';

const DashboardScreen = ({ navigation }) => {
  const [userName, setUserName] = useState('');
  const [activeTrips, setActiveTrips] = useState([]);
  const [pastTrips, setPastTrips] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [showAddTripModal, setShowAddTripModal] = useState(false);
  
  // New trip form state
  const [from, setFrom] = useState('');
  const [to, setTo] = useState('');
  const [date, setDate] = useState('');
  const [time, setTime] = useState('');
  const [price, setPrice] = useState('');
  const [seats, setSeats] = useState('');
  const [carModel, setCarModel] = useState('');
  const [carColor, setCarColor] = useState('');
  
  useEffect(() => {
    // Load user data
    const loadUserData = async () => {
      try {
        const email = await AsyncStorage.getItem('userEmail');
        if (email) {
          // Extract name from email for demo purposes
          const name = email.split('@')[0];
          setUserName(name.charAt(0).toUpperCase() + name.slice(1));
        }
        
        // Load car details if available
        const carDetails = await AsyncStorage.getItem('driverCarDetails');
        if (carDetails) {
          const { model, color } = JSON.parse(carDetails);
          setCarModel(model);
          setCarColor(color);
        }
      } catch (error) {
        console.log('Error loading user data:', error);
      }
    };
    
    // Load trips data
    const loadTripsData = async () => {
      try {
        const tripsData = await AsyncStorage.getItem('driverTrips');
        if (tripsData) {
          const parsedTrips = JSON.parse(tripsData);
          
          // Filter active and past trips based on date
          const now = new Date();
          const active = [];
          const past = [];
          
          parsedTrips.forEach(trip => {
            const [day, month, year] = trip.date.split('-');
            const tripDate = new Date(year, month - 1, day);
            
            if (tripDate >= now) {
              active.push(trip);
            } else {
              past.push(trip);
            }
          });
          
          setActiveTrips(active);
          setPastTrips(past);
        }
        
        setIsLoading(false);
      } catch (error) {
        console.log('Error loading trips data:', error);
        setIsLoading(false);
      }
    };
    
    loadUserData();
    loadTripsData();
  }, []);
  
  const handleAddTrip = async () => {
    // Validate form fields
    if (!from || !to || !date || !time || !price || !seats) {
      Alert.alert('Missing Information', 'Please fill in all required fields.');
      return;
    }
    
    // Validate date format (DD-MM-YYYY)
    const dateRegex = /^(0[1-9]|[12][0-9]|3[01])-(0[1-9]|1[0-2])-\d{4}$/;
    if (!dateRegex.test(date)) {
      Alert.alert('Invalid Date', 'Please enter date in DD-MM-YYYY format.');
      return;
    }
    
    // Validate time format (HH:MM AM/PM)
    const timeRegex = /^(0?[1-9]|1[0-2]):[0-5][0-9] (AM|PM)$/;
    if (!timeRegex.test(time)) {
      Alert.alert('Invalid Time', 'Please enter time in HH:MM AM/PM format.');
      return;
    }
    
    // Validate price (numeric value)
    if (isNaN(parseFloat(price))) {
      Alert.alert('Invalid Price', 'Please enter a valid price.');
      return;
    }
    
    // Validate seats (numeric value between 1 and 10)
    const seatsNum = parseInt(seats);
    if (isNaN(seatsNum) || seatsNum < 1 || seatsNum > 10) {
      Alert.alert('Invalid Seats', 'Please enter a valid number of seats (1-10).');
      return;
    }
    
    // Create new trip object
    const newTrip = {
      id: Date.now().toString(),
      from,
      to,
      date,
      time,
      price: `₦${parseFloat(price).toLocaleString()}`,
      seatsAvailable: seatsNum,
      totalSeats: seatsNum,
      bookedSeats: [],
      driver: userName,
      carModel: carModel || 'Not specified',
      carColor: carColor || 'Not specified',
      status: 'active',
      createdAt: new Date().toISOString(),
    };
    
    try {
      // Get existing trips
      const existingTripsJson = await AsyncStorage.getItem('driverTrips');
      const existingTrips = existingTripsJson ? JSON.parse(existingTripsJson) : [];
      
      // Add new trip to existing trips
      const updatedTrips = [newTrip, ...existingTrips];
      
      // Save updated trips to AsyncStorage
      await AsyncStorage.setItem('driverTrips', JSON.stringify(updatedTrips));
      
      // Save car details if not already saved
      if (carModel && carColor) {
        await AsyncStorage.setItem('driverCarDetails', JSON.stringify({
          model: carModel,
          color: carColor,
        }));
      }
      
      // Update state
      setActiveTrips([newTrip, ...activeTrips]);
      
      // Reset form fields
      setFrom('');
      setTo('');
      setDate('');
      setTime('');
      setPrice('');
      setSeats('');
      
      // Close modal
      setShowAddTripModal(false);
      
      Alert.alert('Success', 'Your trip has been posted successfully!');
    } catch (error) {
      console.log('Error saving trip:', error);
      Alert.alert('Error', 'Failed to save trip. Please try again.');
    }
  };
  
  const handleTripPress = (trip) => {
    navigation.navigate('TripDetails', { trip });
  };
  
  const renderTripItem = ({ item }) => {
    // Calculate booked seats
    const bookedCount = item.bookedSeats ? item.bookedSeats.length : 0;
    const availableSeats = item.seatsAvailable;
    
    return (
      <TouchableOpacity
        style={styles.tripCard}
        onPress={() => handleTripPress(item)}
      >
        <View style={styles.tripHeader}>
          <View style={styles.locationContainer}>
            <Text style={styles.fromText}>{item.from}</Text>
            <View style={styles.arrowContainer}>
              <View style={styles.arrowLine} />
              <Text style={styles.arrowHead}>▶</Text>
            </View>
            <Text style={styles.toText}>{item.to}</Text>
          </View>
          <Text style={styles.priceText}>{item.price}</Text>
        </View>
        
        <View style={styles.tripDetails}>
          <View style={styles.detailItem}>
            <Text style={styles.detailLabel}>Date:</Text>
            <Text style={styles.detailValue}>{item.date}</Text>
          </View>
          <View style={styles.detailItem}>
            <Text style={styles.detailLabel}>Time:</Text>
            <Text style={styles.detailValue}>{item.time}</Text>
          </View>
          <View style={styles.detailItem}>
            <Text style={styles.detailLabel}>Seats:</Text>
            <Text style={styles.detailValue}>
              {bookedCount}/{item.totalSeats} booked
            </Text>
          </View>
        </View>
        
        <View style={styles.tripStatus}>
          <View style={styles.statusIndicator}>
            <View style={[
              styles.statusDot,
              { backgroundColor: bookedCount > 0 ? '#FFC107' : '#008000' }
            ]} />
            <Text style={styles.statusText}>
              {bookedCount === 0 ? 'No bookings yet' : 
               bookedCount === item.totalSeats ? 'Fully booked' : 
               `${bookedCount} seat${bookedCount !== 1 ? 's' : ''} booked`}
            </Text>
          </View>
          <TouchableOpacity style={styles.viewButton}>
            <Text style={styles.viewButtonText}>View</Text>
          </TouchableOpacity>
        </View>
      </TouchableOpacity>
    );
  };
  
  const renderEmptyTrips = () => (
    <View style={styles.emptyContainer}>
      <Text style={styles.emptyText}>No trips found</Text>
      <Text style={styles.emptySubtext}>Add a new trip to get started</Text>
    </View>
  );
  
  return (
    <View style={styles.container}>
      <StatusBar style="light" />
      
      <View style={styles.header}>
        <View>
          <Text style={styles.welcomeText}>Welcome,</Text>
          <Text style={styles.userName}>{userName || 'Driver'}</Text>
        </View>
        <TouchableOpacity style={styles.profileButton}>
          <View style={styles.profileIcon}>
            <Text style={styles.profileInitial}>{userName ? userName.charAt(0) : 'D'}</Text>
          </View>
        </TouchableOpacity>
      </View>
      
      <ScrollView contentContainerStyle={styles.scrollContent}>
        <View style={styles.statsContainer}>
          <View style={styles.statCard}>
            <Text style={styles.statValue}>{activeTrips.length}</Text>
            <Text style={styles.statLabel}>Active Trips</Text>
          </View>
          
          <View style={styles.statCard}>
            <Text style={styles.statValue}>
              {activeTrips.reduce((total, trip) => {
                const bookedCount = trip.bookedSeats ? trip.bookedSeats.length : 0;
                return total + bookedCount;
              }, 0)}
            </Text>
            <Text style={styles.statLabel}>Booked Seats</Text>
          </View>
          
          <View style={styles.statCard}>
            <Text style={styles.statValue}>{pastTrips.length}</Text>
            <Text style={styles.statLabel}>Completed</Text>
          </View>
        </View>
        
        <View style={styles.addTripContainer}>
          <TouchableOpacity
            style={styles.addTripButton}
            onPress={() => setShowAddTripModal(true)}
          >
            <Text style={styles.addTripButtonText}>+ Add New Trip</Text>
          </TouchableOpacity>
        </View>
        
        <View style={styles.tripsContainer}>
          <Text style={styles.sectionTitle}>Active Trips</Text>
          
          {isLoading ? (
            <ActivityIndicator size="large" color="#008000" style={styles.loader} />
          ) : (
            <FlatList
              data={activeTrips}
              renderItem={renderTripItem}
              keyExtractor={(item) => item.id}
              ListEmptyComponent={renderEmptyTrips}
              scrollEnabled={false}
              contentContainerStyle={styles.tripsList}
            />
          )}
        </View>
        
        {pastTrips.length > 0 && (
          <View style={styles.tripsContainer}>
            <Text style={styles.sectionTitle}>Past Trips</Text>
            
            <FlatList
              data={pastTrips.slice(0, 3)} // Show only the 3 most recent past trips
              renderItem={renderTripItem}
              keyExtractor={(item) => item.id}
              scrollEnabled={false}
              contentContainerStyle={styles.tripsList}
            />
            
            {pastTrips.length > 3 && (
              <TouchableOpacity
                style={styles.viewAllButton}
                onPress={() => navigation.navigate('PastTrips')}
              >
                <Text style={styles.viewAllButtonText}>View All Past Trips</Text>
              </TouchableOpacity>
            )}
          </View>
        )}
      </ScrollView>
      
      {/* Add Trip Modal */}
      <Modal
        visible={showAddTripModal}
        transparent={true}
        animationType="slide"
        onRequestClose={() => setShowAddTripModal(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Add New Trip</Text>
              <TouchableOpacity
                style={styles.closeButton}
                onPress={() => setShowAddTripModal(false)}
              >
                <Text style={styles.closeButtonText}>×</Text>
              </TouchableOpacity>
            </View>
            
            <ScrollView contentContainerStyle={styles.formContainer}>
              <View style={styles.formGroup}>
                <Text style={styles.inputLabel}>From</Text>
                <TextInput
                  style={styles.input}
                  placeholder="Departure City"
                  value={from}
                  onChangeText={setFrom}
                />
              </View>
              
              <View style={styles.formGroup}>
                <Text style={styles.inputLabel}>To</Text>
                <TextInput
                  style={styles.input}
                  placeholder="Destination City"
                  value={to}
                  onChangeText={setTo}
                />
              </View>
              
              <View style={styles.formRow}>
                <View style={[styles.formGroup, styles.halfWidth]}>
                  <Text style={styles.inputLabel}>Date</Text>
                  <TextInput
                    style={styles.input}
                    placeholder="DD-MM-YYYY"
                    value={date}
                    onChangeText={setDate}
                  />
                </View>
                
                <View style={[styles.formGroup, styles.halfWidth]}>
                  <Text style={styles.inputLabel}>Time</Text>
                  <TextInput
                    style={styles.input}
                    placeholder="HH:MM AM/PM"
                    value={time}
                    onChangeText={setTime}
                  />
                </View>
              </View>
              
              <View style={styles.formRow}>
                <View style={[styles.formGroup, styles.halfWidth]}>
                  <Text style={styles.inputLabel}>Price (₦)</Text>
                  <TextInput
                    style={styles.input}
                    placeholder="Price per seat"
                    keyboardType="numeric"
                    value={price}
                    onChangeText={setPrice}
                  />
                </View>
                
                <View style={[styles.formGroup, styles.halfWidth]}>
                  <Text style={styles.inputLabel}>Available Seats</Text>
                  <TextInput
                    style={styles.input}
                    placeholder="Number of seats"
                    keyboardType="numeric"
                    value={seats}
                    onChangeText={setSeats}
                  />
                </View>
              </View>
              
              <View style={styles.formRow}>
                <View style={[styles.formGroup, styles.halfWidth]}>
                  <Text style={styles.inputLabel}>Car Model</Text>
                  <TextInput
                    style={styles.input}
                    placeholder="e.g. Toyota Camry"
                    value={carModel}
                    onChangeText={setCarModel}
                  />
                </View>
                
                <View style={[styles.formGroup, styles.halfWidth]}>
                  <Text style={styles.inputLabel}>Car Color</Text>
                  <TextInput
                    style={styles.input}
                    placeholder="e.g. Black"
                    value={carColor}
                    onChangeText={setCarColor}
                  />
                </View>
              </View>
            </ScrollView>
            
            <View style={styles.modalFooter}>
              <TouchableOpacity
                style={styles.cancelButton}
                onPress={() => setShowAddTripModal(false)}
              >
                <Text style={styles.cancelButtonText}>Cancel</Text>
              </TouchableOpacity>
              
              <TouchableOpacity
                style={styles.saveButton}
                onPress={handleAddTrip}
              >
                <Text style={styles.saveButtonText}>Post Trip</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F5F5',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: '#008000',
    paddingTop: 50,
    paddingBottom: 20,
    paddingHorizontal: 20,
  },
  welcomeText: {
    fontSize: 16,
    color: 'rgba(255, 255, 255, 0.8)',
  },
  userName: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#FFFFFF',
  },
  profileButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  profileIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
  },
  profileInitial: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: 'bold',
  },
  scrollContent: {
    padding: 20,
  },
  statsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 20,
  },
  statCard: {
    flex: 1,
    backgroundColor: '#FFFFFF',
    borderRadius: 10,
    padding: 15,
    alignItems: 'center',
    marginHorizontal: 5,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  statValue: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#008000',
    marginBottom: 5,
  },
  statLabel: {
    fontSize: 12,
    color: '#666666',
    textAlign: 'center',
  },
  addTripContainer: {
    marginBottom: 20,
  },
  addTripButton: {
    backgroundColor: '#008000',
    borderRadius: 10,
    padding: 15,
    alignItems: 'center',
  },
  addTripButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
  tripsContainer: {
    marginBottom: 20,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333333',
    marginBottom: 15,
  },
  loader: {
    marginTop: 20,
  },
  tripsList: {
    paddingBottom: 10,
  },
  tripCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 15,
    padding: 15,
    marginBottom: 15,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  tripHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 15,
  },
  locationContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  fromText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333333',
  },
  arrowContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginHorizontal: 10,
  },
  arrowLine: {
    height: 1,
    width: 30,
    backgroundColor: '#CCCCCC',
  },
  arrowHead: {
    color: '#CCCCCC',
    fontSize: 12,
  },
  toText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333333',
  },
  priceText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#008000',
  },
  tripDetails: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 15,
    paddingBottom: 15,
    borderBottomWidth: 1,
    borderBottomColor: '#EEEEEE',
  },
  detailItem: {
    flexDirection: 'column',
  },
  detailLabel: {
    fontSize: 12,
    color: '#999999',
    marginBottom: 5,
  },
  detailValue: {
    fontSize: 14,
    color: '#333333',
    fontWeight: '500',
  },
  tripStatus: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  statusIndicator: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  statusDot: {
    width: 10,
    height: 10,
    borderRadius: 5,
    marginRight: 5,
  },
  statusText: {
    fontSize: 14,
    color: '#666666',
  },
  viewButton: {
    backgroundColor: '#E8F5E9',
    paddingHorizontal: 15,
    paddingVertical: 8,
    borderRadius: 20,
  },
  viewButtonText: {
    color: '#008000',
    fontSize: 14,
    fontWeight: '500',
  },
  emptyContainer: {
    alignItems: 'center',
    padding: 30,
    backgroundColor: '#FFFFFF',
    borderRadius: 15,
    marginBottom: 15,
  },
  emptyText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333333',
    marginBottom: 5,
  },
  emptySubtext: {
    fontSize: 14,
    color: '#666666',
    textAlign: 'center',
  },
  viewAllButton: {
    alignItems: 'center',
    padding: 10,
  },
  viewAllButtonText: {
    color: '#008000',
    fontSize: 14,
    fontWeight: '500',
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'flex-end',
  },
  modalContent: {
    backgroundColor: '#FFFFFF',
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    maxHeight: '90%',
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#EEEEEE',
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333333',
  },
  closeButton: {
    width: 30,
    height: 30,
    borderRadius: 15,
    backgroundColor: '#F5F5F5',
    justifyContent: 'center',
    alignItems: 'center',
  },
  closeButtonText: {
    fontSize: 20,
    color: '#666666',
    fontWeight: 'bold',
  },
  formContainer: {
    padding: 20,
  },
  formGroup: {
    marginBottom: 15,
  },
  formRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  halfWidth: {
    width: '48%',
  },
  inputLabel: {
    fontSize: 14,
    color: '#666666',
    marginBottom: 5,
  },
  input: {
    backgroundColor: '#F5F5F5',
    borderRadius: 10,
    padding: 15,
    fontSize: 16,
    color: '#333333',
    borderWidth: 1,
    borderColor: '#EEEEEE',
  },
  modalFooter: {
    flexDirection: 'row',
    padding: 20,
    borderTopWidth: 1,
    borderTopColor: '#EEEEEE',
  },
  cancelButton: {
    flex: 1,
    backgroundColor: '#F5F5F5',
    borderRadius: 10,
    padding: 15,
    alignItems: 'center',
    marginRight: 10,
  },
  cancelButtonText: {
    color: '#666666',
    fontSize: 16,
    fontWeight: '500',
  },
  saveButton: {
    flex: 1,
    backgroundColor: '#008000',
    borderRadius: 10,
    padding: 15,
    alignItems: 'center',
  },
  saveButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
});

export default DashboardScreen;