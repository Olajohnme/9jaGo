import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  TextInput,
  Alert,
  Switch,
  Modal,
  ActivityIndicator,
  Image,
} from 'react-native';
import { StatusBar } from 'expo-status-bar';
import AsyncStorage from '@react-native-async-storage/async-storage';

const ProfileScreen = ({ navigation }) => {
  const [userData, setUserData] = useState({
    fullName: '',
    email: '',
    phone: '',
    userType: 'driver',
    carModel: '',
    carColor: '',
    licensePlate: '',
    driverLicense: '',
  });
  
  const [isEditing, setIsEditing] = useState(false);
  const [editedData, setEditedData] = useState({});
  const [isLoading, setIsLoading] = useState(false);
  const [showLogoutModal, setShowLogoutModal] = useState(false);
  
  // Notification preferences
  const [notificationPrefs, setNotificationPrefs] = useState({
    bookingAlerts: true,
    tripReminders: true,
    paymentNotifications: true,
    promotions: true,
  });
  
  // Driver stats
  const [driverStats, setDriverStats] = useState({
    totalTrips: 0,
    totalPassengers: 0,
    totalEarnings: 0,
    rating: 0,
  });
  
  useEffect(() => {
    loadUserData();
    loadNotificationPreferences();
    loadDriverStats();
  }, []);
  
  const loadUserData = async () => {
    try {
      const data = await AsyncStorage.getItem('userData');
      if (data) {
        setUserData(JSON.parse(data));
      } else {
        // Create mock data for demo
        const mockData = {
          fullName: 'Oluwaseun Adeyemi',
          email: 'oluwaseun@example.com',
          phone: '+2348012345678',
          userType: 'driver',
          carModel: 'Toyota Camry',
          carColor: 'Black',
          licensePlate: 'LAG-123-XY',
          driverLicense: 'DL12345678',
        };
        setUserData(mockData);
        await AsyncStorage.setItem('userData', JSON.stringify(mockData));
      }
    } catch (error) {
      console.log('Error loading user data:', error);
    }
  };
  
  const loadNotificationPreferences = async () => {
    try {
      const prefs = await AsyncStorage.getItem('notificationPreferences');
      if (prefs) {
        setNotificationPrefs(JSON.parse(prefs));
      }
    } catch (error) {
      console.log('Error loading notification preferences:', error);
    }
  };
  
  const loadDriverStats = async () => {
    try {
      const stats = await AsyncStorage.getItem('driverStats');
      if (stats) {
        setDriverStats(JSON.parse(stats));
      } else {
        // Create mock stats for demo
        const mockStats = {
          totalTrips: Math.floor(Math.random() * 50) + 10,
          totalPassengers: Math.floor(Math.random() * 200) + 50,
          totalEarnings: Math.floor(Math.random() * 500000) + 100000,
          rating: (Math.random() * 1) + 4, // Random rating between 4.0 and 5.0
        };
        setDriverStats(mockStats);
        await AsyncStorage.setItem('driverStats', JSON.stringify(mockStats));
      }
    } catch (error) {
      console.log('Error loading driver stats:', error);
    }
  };
  
  const handleEditProfile = () => {
    setEditedData({ ...userData });
    setIsEditing(true);
  };
  
  const handleCancelEdit = () => {
    setIsEditing(false);
  };
  
  const handleSaveProfile = async () => {
    // Validate inputs
    if (!editedData.fullName || !editedData.email || !editedData.phone ||
        !editedData.carModel || !editedData.carColor || !editedData.licensePlate) {
      Alert.alert('Error', 'All fields are required');
      return;
    }
    
    // Email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(editedData.email)) {
      Alert.alert('Error', 'Please enter a valid email address');
      return;
    }
    
    // Phone validation (Nigerian format)
    const phoneRegex = /^(\+234|0)[0-9]{10}$/;
    if (!phoneRegex.test(editedData.phone)) {
      Alert.alert('Error', 'Please enter a valid Nigerian phone number');
      return;
    }
    
    // License plate validation (Nigerian format)
    const plateRegex = /^[A-Z]{3}-[0-9]{3}-[A-Z]{2}$/;
    if (!plateRegex.test(editedData.licensePlate)) {
      Alert.alert('Error', 'Please enter a valid license plate number (e.g., LAG-123-XY)');
      return;
    }
    
    setIsLoading(true);
    
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Update user data
      await AsyncStorage.setItem('userData', JSON.stringify(editedData));
      setUserData(editedData);
      setIsEditing(false);
      
      Alert.alert('Success', 'Profile updated successfully');
    } catch (error) {
      console.log('Error updating profile:', error);
      Alert.alert('Error', 'Failed to update profile. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };
  
  const handleToggleNotification = async (key, value) => {
    try {
      const updatedPrefs = { ...notificationPrefs, [key]: value };
      setNotificationPrefs(updatedPrefs);
      await AsyncStorage.setItem('notificationPreferences', JSON.stringify(updatedPrefs));
    } catch (error) {
      console.log('Error updating notification preferences:', error);
    }
  };
  
  const handleLogout = async () => {
    setShowLogoutModal(false);
    setIsLoading(true);
    
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Clear user session
      await AsyncStorage.removeItem('userToken');
      await AsyncStorage.removeItem('userType');
      
      // Navigate to login screen
      navigation.reset({
        index: 0,
        routes: [{ name: 'Login' }],
      });
    } catch (error) {
      console.log('Error logging out:', error);
      Alert.alert('Error', 'Failed to log out. Please try again.');
      setIsLoading(false);
    }
  };
  
  return (
    <View style={styles.container}>
      <StatusBar style="light" />
      
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Driver Profile</Text>
        {!isEditing && (
          <TouchableOpacity
            style={styles.editButton}
            onPress={handleEditProfile}
          >
            <Text style={styles.editButtonText}>Edit</Text>
          </TouchableOpacity>
        )}
      </View>
      
      <ScrollView contentContainerStyle={styles.scrollContent}>
        <View style={styles.profileSection}>
          <View style={styles.profileAvatar}>
            <Text style={styles.profileInitial}>
              {userData.fullName ? userData.fullName.charAt(0).toUpperCase() : 'D'}
            </Text>
          </View>
          
          <Text style={styles.profileName}>{userData.fullName}</Text>
          <View style={styles.ratingContainer}>
            <Text style={styles.ratingText}>{driverStats.rating.toFixed(1)}</Text>
            <Text style={styles.starIcon}>★</Text>
          </View>
        </View>
        
        <View style={styles.statsContainer}>
          <View style={styles.statCard}>
            <Text style={styles.statValue}>{driverStats.totalTrips}</Text>
            <Text style={styles.statLabel}>Trips</Text>
          </View>
          
          <View style={styles.statCard}>
            <Text style={styles.statValue}>{driverStats.totalPassengers}</Text>
            <Text style={styles.statLabel}>Passengers</Text>
          </View>
          
          <View style={styles.statCard}>
            <Text style={styles.statValue}>₦{driverStats.totalEarnings.toLocaleString()}</Text>
            <Text style={styles.statLabel}>Earnings</Text>
          </View>
        </View>
        
        <View style={styles.infoCard}>
          <Text style={styles.sectionTitle}>Personal Information</Text>
          
          <View style={styles.infoItem}>
            <Text style={styles.infoLabel}>Full Name</Text>
            {isEditing ? (
              <TextInput
                style={styles.input}
                value={editedData.fullName}
                onChangeText={(text) => setEditedData({ ...editedData, fullName: text })}
                placeholder="Enter your full name"
              />
            ) : (
              <Text style={styles.infoValue}>{userData.fullName}</Text>
            )}
          </View>
          
          <View style={styles.infoItem}>
            <Text style={styles.infoLabel}>Email</Text>
            {isEditing ? (
              <TextInput
                style={styles.input}
                value={editedData.email}
                onChangeText={(text) => setEditedData({ ...editedData, email: text })}
                placeholder="Enter your email"
                keyboardType="email-address"
                autoCapitalize="none"
              />
            ) : (
              <Text style={styles.infoValue}>{userData.email}</Text>
            )}
          </View>
          
          <View style={styles.infoItem}>
            <Text style={styles.infoLabel}>Phone Number</Text>
            {isEditing ? (
              <TextInput
                style={styles.input}
                value={editedData.phone}
                onChangeText={(text) => setEditedData({ ...editedData, phone: text })}
                placeholder="Enter your phone number"
                keyboardType="phone-pad"
              />
            ) : (
              <Text style={styles.infoValue}>{userData.phone}</Text>
            )}
          </View>
        </View>
        
        <View style={styles.infoCard}>
          <Text style={styles.sectionTitle}>Vehicle Information</Text>
          
          <View style={styles.infoItem}>
            <Text style={styles.infoLabel}>Car Model</Text>
            {isEditing ? (
              <TextInput
                style={styles.input}
                value={editedData.carModel}
                onChangeText={(text) => setEditedData({ ...editedData, carModel: text })}
                placeholder="Enter your car model"
              />
            ) : (
              <Text style={styles.infoValue}>{userData.carModel}</Text>
            )}
          </View>
          
          <View style={styles.infoItem}>
            <Text style={styles.infoLabel}>Car Color</Text>
            {isEditing ? (
              <TextInput
                style={styles.input}
                value={editedData.carColor}
                onChangeText={(text) => setEditedData({ ...editedData, carColor: text })}
                placeholder="Enter your car color"
              />
            ) : (
              <Text style={styles.infoValue}>{userData.carColor}</Text>
            )}
          </View>
          
          <View style={styles.infoItem}>
            <Text style={styles.infoLabel}>License Plate</Text>
            {isEditing ? (
              <TextInput
                style={styles.input}
                value={editedData.licensePlate}
                onChangeText={(text) => setEditedData({ ...editedData, licensePlate: text })}
                placeholder="Enter your license plate (e.g., LAG-123-XY)"
                autoCapitalize="characters"
              />
            ) : (
              <Text style={styles.infoValue}>{userData.licensePlate}</Text>
            )}
          </View>
          
          <View style={styles.infoItem}>
            <Text style={styles.infoLabel}>Driver License</Text>
            {isEditing ? (
              <TextInput
                style={styles.input}
                value={editedData.driverLicense}
                onChangeText={(text) => setEditedData({ ...editedData, driverLicense: text })}
                placeholder="Enter your driver license number"
              />
            ) : (
              <Text style={styles.infoValue}>{userData.driverLicense}</Text>
            )}
          </View>
          
          {isEditing && (
            <View style={styles.editActions}>
              <TouchableOpacity
                style={styles.cancelButton}
                onPress={handleCancelEdit}
              >
                <Text style={styles.cancelButtonText}>Cancel</Text>
              </TouchableOpacity>
              
              <TouchableOpacity
                style={styles.saveButton}
                onPress={handleSaveProfile}
              >
                <Text style={styles.saveButtonText}>Save</Text>
              </TouchableOpacity>
            </View>
          )}
        </View>
        
        <View style={styles.infoCard}>
          <Text style={styles.sectionTitle}>Notification Preferences</Text>
          
          <View style={styles.toggleItem}>
            <Text style={styles.toggleLabel}>Booking Alerts</Text>
            <Switch
              trackColor={{ false: '#CCCCCC', true: '#A5D6A7' }}
              thumbColor={notificationPrefs.bookingAlerts ? '#008000' : '#F5F5F5'}
              onValueChange={(value) => handleToggleNotification('bookingAlerts', value)}
              value={notificationPrefs.bookingAlerts}
            />
          </View>
          
          <View style={styles.toggleItem}>
            <Text style={styles.toggleLabel}>Trip Reminders</Text>
            <Switch
              trackColor={{ false: '#CCCCCC', true: '#A5D6A7' }}
              thumbColor={notificationPrefs.tripReminders ? '#008000' : '#F5F5F5'}
              onValueChange={(value) => handleToggleNotification('tripReminders', value)}
              value={notificationPrefs.tripReminders}
            />
          </View>
          
          <View style={styles.toggleItem}>
            <Text style={styles.toggleLabel}>Payment Notifications</Text>
            <Switch
              trackColor={{ false: '#CCCCCC', true: '#A5D6A7' }}
              thumbColor={notificationPrefs.paymentNotifications ? '#008000' : '#F5F5F5'}
              onValueChange={(value) => handleToggleNotification('paymentNotifications', value)}
              value={notificationPrefs.paymentNotifications}
            />
          </View>
          
          <View style={styles.toggleItem}>
            <Text style={styles.toggleLabel}>Promotions & Offers</Text>
            <Switch
              trackColor={{ false: '#CCCCCC', true: '#A5D6A7' }}
              thumbColor={notificationPrefs.promotions ? '#008000' : '#F5F5F5'}
              onValueChange={(value) => handleToggleNotification('promotions', value)}
              value={notificationPrefs.promotions}
            />
          </View>
        </View>
        
        <TouchableOpacity
          style={styles.logoutButton}
          onPress={() => setShowLogoutModal(true)}
        >
          <Text style={styles.logoutButtonText}>Log Out</Text>
        </TouchableOpacity>
      </ScrollView>
      
      {/* Logout Confirmation Modal */}
      <Modal
        visible={showLogoutModal}
        transparent={true}
        animationType="fade"
        onRequestClose={() => setShowLogoutModal(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>Log Out</Text>
            <Text style={styles.modalMessage}>Are you sure you want to log out?</Text>
            
            <View style={styles.modalActions}>
              <TouchableOpacity
                style={styles.modalCancelButton}
                onPress={() => setShowLogoutModal(false)}
              >
                <Text style={styles.modalCancelButtonText}>Cancel</Text>
              </TouchableOpacity>
              
              <TouchableOpacity
                style={styles.modalConfirmButton}
                onPress={handleLogout}
              >
                <Text style={styles.modalConfirmButtonText}>Log Out</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
      
      {/* Loading Indicator */}
      {isLoading && (
        <View style={styles.loadingOverlay}>
          <ActivityIndicator size="large" color="#008000" />
        </View>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F5F5',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: '#008000',
    paddingTop: 50,
    paddingBottom: 15,
    paddingHorizontal: 20,
  },
  headerTitle: {
    color: '#FFFFFF',
    fontSize: 20,
    fontWeight: 'bold',
  },
  editButton: {
    paddingHorizontal: 15,
    paddingVertical: 8,
    borderRadius: 20,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
  },
  editButtonText: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: '500',
  },
  scrollContent: {
    padding: 20,
    paddingBottom: 40,
  },
  profileSection: {
    alignItems: 'center',
    marginBottom: 20,
  },
  profileAvatar: {
    width: 100,
    height: 100,
    borderRadius: 50,
    backgroundColor: '#E8F5E9',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 15,
  },
  profileInitial: {
    fontSize: 40,
    fontWeight: 'bold',
    color: '#008000',
  },
  profileName: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#333333',
    marginBottom: 5,
  },
  ratingContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
  },
  ratingText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#FF9800',
    marginRight: 5,
  },
  starIcon: {
    fontSize: 16,
    color: '#FF9800',
  },
  statsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 20,
  },
  statCard: {
    flex: 1,
    backgroundColor: '#FFFFFF',
    borderRadius: 10,
    padding: 15,
    alignItems: 'center',
    marginHorizontal: 5,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  statValue: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#008000',
    marginBottom: 5,
  },
  statLabel: {
    fontSize: 12,
    color: '#666666',
    textAlign: 'center',
  },
  infoCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 15,
    padding: 20,
    marginBottom: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333333',
    marginBottom: 15,
  },
  infoItem: {
    marginBottom: 15,
  },
  infoLabel: {
    fontSize: 14,
    color: '#666666',
    marginBottom: 5,
  },
  infoValue: {
    fontSize: 16,
    color: '#333333',
  },
  input: {
    borderWidth: 1,
    borderColor: '#DDDDDD',
    borderRadius: 8,
    paddingHorizontal: 15,
    paddingVertical: 10,
    fontSize: 16,
    color: '#333333',
  },
  editActions: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    marginTop: 20,
  },
  cancelButton: {
    backgroundColor: '#F5F5F5',
    borderRadius: 8,
    paddingVertical: 10,
    paddingHorizontal: 20,
    marginRight: 10,
  },
  cancelButtonText: {
    color: '#666666',
    fontSize: 14,
    fontWeight: '500',
  },
  saveButton: {
    backgroundColor: '#008000',
    borderRadius: 8,
    paddingVertical: 10,
    paddingHorizontal: 20,
  },
  saveButtonText: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: '500',
  },
  toggleItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 15,
  },
  toggleLabel: {
    fontSize: 16,
    color: '#333333',
  },
  logoutButton: {
    backgroundColor: '#FFEBEE',
    borderRadius: 10,
    padding: 15,
    alignItems: 'center',
    marginTop: 10,
  },
  logoutButtonText: {
    color: '#D32F2F',
    fontSize: 16,
    fontWeight: '500',
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalContent: {
    backgroundColor: '#FFFFFF',
    borderRadius: 15,
    padding: 20,
    width: '80%',
    alignItems: 'center',
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333333',
    marginBottom: 10,
  },
  modalMessage: {
    fontSize: 16,
    color: '#666666',
    marginBottom: 20,
    textAlign: 'center',
  },
  modalActions: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: '100%',
  },
  modalCancelButton: {
    backgroundColor: '#F5F5F5',
    borderRadius: 8,
    paddingVertical: 10,
    paddingHorizontal: 20,
    flex: 1,
    marginRight: 10,
    alignItems: 'center',
  },
  modalCancelButtonText: {
    color: '#666666',
    fontSize: 14,
    fontWeight: '500',
  },
  modalConfirmButton: {
    backgroundColor: '#FFEBEE',
    borderRadius: 8,
    paddingVertical: 10,
    paddingHorizontal: 20,
    flex: 1,
    alignItems: 'center',
  },
  modalConfirmButtonText: {
    color: '#D32F2F',
    fontSize: 14,
    fontWeight: '500',
  },
  loadingOverlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(255, 255, 255, 0.7)',
    justifyContent: 'center',
    alignItems: 'center',
  },
});

export default ProfileScreen;