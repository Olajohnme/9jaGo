import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Alert,
  FlatList,
  Modal,
} from 'react-native';
import { StatusBar } from 'expo-status-bar';
import AsyncStorage from '@react-native-async-storage/async-storage';

const TripDetailsScreen = ({ route, navigation }) => {
  const { trip } = route.params;
  const [bookings, setBookings] = useState([]);
  const [showPassengerModal, setShowPassengerModal] = useState(false);
  const [selectedPassenger, setSelectedPassenger] = useState(null);
  
  useEffect(() => {
    // Load bookings for this trip
    loadBookings();
  }, []);
  
  const loadBookings = async () => {
    try {
      // In a real app, this would be fetched from a backend API
      // For demo purposes, we'll create mock bookings if none exist
      const bookingsData = await AsyncStorage.getItem(`bookings_${trip.id}`);
      
      if (bookingsData) {
        setBookings(JSON.parse(bookingsData));
      } else {
        // Create mock bookings for demo
        if (trip.bookedSeats && trip.bookedSeats.length > 0) {
          const mockBookings = trip.bookedSeats.map((seatNumber, index) => ({
            id: `booking_${index + 1}`,
            passengerName: getRandomName(),
            passengerPhone: getRandomPhone(),
            seatNumber,
            bookingDate: new Date(Date.now() - Math.random() * 86400000 * 3).toISOString(),
            checkedIn: Math.random() > 0.5,
          }));
          
          setBookings(mockBookings);
          await AsyncStorage.setItem(`bookings_${trip.id}`, JSON.stringify(mockBookings));
        }
      }
    } catch (error) {
      console.log('Error loading bookings:', error);
    }
  };
  
  const getRandomName = () => {
    const firstNames = ['John', 'Mary', 'David', 'Sarah', 'Michael', 'Jennifer', 'Chioma', 'Emeka', 'Ngozi', 'Oluwaseun'];
    const lastNames = ['Smith', 'Johnson', 'Williams', 'Brown', 'Jones', 'Okonkwo', 'Adeyemi', 'Okafor', 'Nwachukwu', 'Eze'];
    
    return `${firstNames[Math.floor(Math.random() * firstNames.length)]} ${lastNames[Math.floor(Math.random() * lastNames.length)]}`;
  };
  
  const getRandomPhone = () => {
    return `+234${Math.floor(Math.random() * 10)}${Math.floor(Math.random() * 10000000).toString().padStart(7, '0')}`;
  };
  
  const handlePassengerPress = (passenger) => {
    setSelectedPassenger(passenger);
    setShowPassengerModal(true);
  };
  
  const handleCheckIn = async (passengerId) => {
    try {
      // Update booking status
      const updatedBookings = bookings.map(booking => {
        if (booking.id === passengerId) {
          return { ...booking, checkedIn: true };
        }
        return booking;
      });
      
      setBookings(updatedBookings);
      await AsyncStorage.setItem(`bookings_${trip.id}`, JSON.stringify(updatedBookings));
      
      // Close modal
      setShowPassengerModal(false);
      
      Alert.alert('Success', 'Passenger has been checked in successfully!');
    } catch (error) {
      console.log('Error checking in passenger:', error);
      Alert.alert('Error', 'Failed to check in passenger. Please try again.');
    }
  };
  
  const renderPassengerItem = ({ item }) => (
    <TouchableOpacity
      style={styles.passengerCard}
      onPress={() => handlePassengerPress(item)}
    >
      <View style={styles.passengerInfo}>
        <View style={styles.passengerAvatar}>
          <Text style={styles.passengerInitial}>{item.passengerName.charAt(0)}</Text>
        </View>
        
        <View style={styles.passengerDetails}>
          <Text style={styles.passengerName}>{item.passengerName}</Text>
          <Text style={styles.passengerSeat}>Seat {item.seatNumber}</Text>
        </View>
      </View>
      
      <View style={[
        styles.statusBadge,
        item.checkedIn ? styles.checkedInBadge : styles.notCheckedInBadge
      ]}>
        <Text style={[
          styles.statusText,
          item.checkedIn ? styles.checkedInText : styles.notCheckedInText
        ]}>
          {item.checkedIn ? 'Checked In' : 'Not Checked In'}
        </Text>
      </View>
    </TouchableOpacity>
  );
  
  const renderEmptyBookings = () => (
    <View style={styles.emptyContainer}>
      <Text style={styles.emptyText}>No bookings yet</Text>
      <Text style={styles.emptySubtext}>Bookings will appear here once passengers book seats for this trip</Text>
    </View>
  );
  
  // Calculate booked seats count
  const bookedSeatsCount = bookings.length;
  const availableSeats = trip.totalSeats - bookedSeatsCount;
  
  // Calculate checked-in passengers count
  const checkedInCount = bookings.filter(booking => booking.checkedIn).length;
  
  return (
    <View style={styles.container}>
      <StatusBar style="light" />
      
      <View style={styles.header}>
        <TouchableOpacity
          style={styles.backButton}
          onPress={() => navigation.goBack()}
        >
          <Text style={styles.backButtonText}>←</Text>
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Trip Details</Text>
        <View style={styles.placeholder} />
      </View>
      
      <ScrollView contentContainerStyle={styles.scrollContent}>
        <View style={styles.tripCard}>
          <View style={styles.tripHeader}>
            <View style={styles.locationContainer}>
              <Text style={styles.fromText}>{trip.from}</Text>
              <View style={styles.arrowContainer}>
                <View style={styles.arrowLine} />
                <Text style={styles.arrowHead}>▶</Text>
              </View>
              <Text style={styles.toText}>{trip.to}</Text>
            </View>
          </View>
          
          <View style={styles.tripDetails}>
            <View style={styles.detailItem}>
              <Text style={styles.detailLabel}>Date</Text>
              <Text style={styles.detailValue}>{trip.date}</Text>
            </View>
            
            <View style={styles.detailItem}>
              <Text style={styles.detailLabel}>Time</Text>
              <Text style={styles.detailValue}>{trip.time}</Text>
            </View>
            
            <View style={styles.detailItem}>
              <Text style={styles.detailLabel}>Price</Text>
              <Text style={styles.detailValue}>{trip.price}/seat</Text>
            </View>
          </View>
        </View>
        
        <View style={styles.statsContainer}>
          <View style={styles.statCard}>
            <Text style={styles.statValue}>{bookedSeatsCount}/{trip.totalSeats}</Text>
            <Text style={styles.statLabel}>Seats Booked</Text>
          </View>
          
          <View style={styles.statCard}>
            <Text style={styles.statValue}>{availableSeats}</Text>
            <Text style={styles.statLabel}>Available</Text>
          </View>
          
          <View style={styles.statCard}>
            <Text style={styles.statValue}>{checkedInCount}/{bookedSeatsCount}</Text>
            <Text style={styles.statLabel}>Checked In</Text>
          </View>
        </View>
        
        <View style={styles.passengersContainer}>
          <Text style={styles.sectionTitle}>Passengers</Text>
          
          <FlatList
            data={bookings}
            renderItem={renderPassengerItem}
            keyExtractor={(item) => item.id}
            ListEmptyComponent={renderEmptyBookings}
            scrollEnabled={false}
            contentContainerStyle={styles.passengersList}
          />
        </View>
      </ScrollView>
      
      {/* Passenger Details Modal */}
      <Modal
        visible={showPassengerModal}
        transparent={true}
        animationType="slide"
        onRequestClose={() => setShowPassengerModal(false)}
      >
        {selectedPassenger && (
          <View style={styles.modalOverlay}>
            <View style={styles.modalContent}>
              <View style={styles.modalHeader}>
                <Text style={styles.modalTitle}>Passenger Details</Text>
                <TouchableOpacity
                  style={styles.closeButton}
                  onPress={() => setShowPassengerModal(false)}
                >
                  <Text style={styles.closeButtonText}>×</Text>
                </TouchableOpacity>
              </View>
              
              <View style={styles.passengerModalInfo}>
                <View style={styles.passengerModalAvatar}>
                  <Text style={styles.passengerModalInitial}>
                    {selectedPassenger.passengerName.charAt(0)}
                  </Text>
                </View>
                
                <Text style={styles.passengerModalName}>
                  {selectedPassenger.passengerName}
                </Text>
              </View>
              
              <View style={styles.passengerModalDetails}>
                <View style={styles.passengerModalDetail}>
                  <Text style={styles.passengerModalDetailLabel}>Phone Number:</Text>
                  <Text style={styles.passengerModalDetailValue}>
                    {selectedPassenger.passengerPhone}
                  </Text>
                </View>
                
                <View style={styles.passengerModalDetail}>
                  <Text style={styles.passengerModalDetailLabel}>Seat Number:</Text>
                  <Text style={styles.passengerModalDetailValue}>
                    {selectedPassenger.seatNumber}
                  </Text>
                </View>
                
                <View style={styles.passengerModalDetail}>
                  <Text style={styles.passengerModalDetailLabel}>Booking Date:</Text>
                  <Text style={styles.passengerModalDetailValue}>
                    {new Date(selectedPassenger.bookingDate).toLocaleDateString()}
                  </Text>
                </View>
                
                <View style={styles.passengerModalDetail}>
                  <Text style={styles.passengerModalDetailLabel}>Status:</Text>
                  <View style={[
                    styles.statusBadge,
                    selectedPassenger.checkedIn ? styles.checkedInBadge : styles.notCheckedInBadge
                  ]}>
                    <Text style={[
                      styles.statusText,
                      selectedPassenger.checkedIn ? styles.checkedInText : styles.notCheckedInText
                    ]}>
                      {selectedPassenger.checkedIn ? 'Checked In' : 'Not Checked In'}
                    </Text>
                  </View>
                </View>
              </View>
              
              <View style={styles.modalFooter}>
                <TouchableOpacity
                  style={styles.closeModalButton}
                  onPress={() => setShowPassengerModal(false)}
                >
                  <Text style={styles.closeModalButtonText}>Close</Text>
                </TouchableOpacity>
                
                {!selectedPassenger.checkedIn && (
                  <TouchableOpacity
                    style={styles.checkInButton}
                    onPress={() => handleCheckIn(selectedPassenger.id)}
                  >
                    <Text style={styles.checkInButtonText}>Check In</Text>
                  </TouchableOpacity>
                )}
              </View>
            </View>
          </View>
        )}
      </Modal>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F5F5',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: '#008000',
    paddingTop: 50,
    paddingBottom: 15,
    paddingHorizontal: 20,
  },
  backButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  backButtonText: {
    color: '#FFFFFF',
    fontSize: 24,
    fontWeight: 'bold',
  },
  headerTitle: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: 'bold',
  },
  placeholder: {
    width: 40,
  },
  scrollContent: {
    padding: 20,
  },
  tripCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 15,
    padding: 20,
    marginBottom: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  tripHeader: {
    marginBottom: 20,
  },
  locationContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  fromText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333333',
  },
  arrowContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginHorizontal: 10,
  },
  arrowLine: {
    height: 1,
    width: 50,
    backgroundColor: '#CCCCCC',
  },
  arrowHead: {
    color: '#CCCCCC',
    fontSize: 12,
  },
  toText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333333',
  },
  tripDetails: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  detailItem: {
    alignItems: 'center',
  },
  detailLabel: {
    fontSize: 12,
    color: '#999999',
    marginBottom: 5,
  },
  detailValue: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333333',
  },
  statsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 20,
  },
  statCard: {
    flex: 1,
    backgroundColor: '#FFFFFF',
    borderRadius: 10,
    padding: 15,
    alignItems: 'center',
    marginHorizontal: 5,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  statValue: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#008000',
    marginBottom: 5,
  },
  statLabel: {
    fontSize: 12,
    color: '#666666',
    textAlign: 'center',
  },
  passengersContainer: {
    marginBottom: 20,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333333',
    marginBottom: 15,
  },
  passengersList: {
    paddingBottom: 10,
  },
  passengerCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 15,
    padding: 15,
    marginBottom: 15,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  passengerInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  passengerAvatar: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#E8F5E9',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 10,
  },
  passengerInitial: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#008000',
  },
  passengerDetails: {
    flex: 1,
  },
  passengerName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333333',
    marginBottom: 5,
  },
  passengerSeat: {
    fontSize: 14,
    color: '#666666',
  },
  statusBadge: {
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 20,
  },
  checkedInBadge: {
    backgroundColor: '#E8F5E9',
  },
  notCheckedInBadge: {
    backgroundColor: '#FFF3E0',
  },
  statusText: {
    fontSize: 12,
    fontWeight: '500',
  },
  checkedInText: {
    color: '#008000',
  },
  notCheckedInText: {
    color: '#FF9800',
  },
  emptyContainer: {
    alignItems: 'center',
    padding: 30,
    backgroundColor: '#FFFFFF',
    borderRadius: 15,
    marginBottom: 15,
  },
  emptyText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333333',
    marginBottom: 5,
  },
  emptySubtext: {
    fontSize: 14,
    color: '#666666',
    textAlign: 'center',
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'flex-end',
  },
  modalContent: {
    backgroundColor: '#FFFFFF',
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#EEEEEE',
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333333',
  },
  closeButton: {
    width: 30,
    height: 30,
    borderRadius: 15,
    backgroundColor: '#F5F5F5',
    justifyContent: 'center',
    alignItems: 'center',
  },
  closeButtonText: {
    fontSize: 20,
    color: '#666666',
    fontWeight: 'bold',
  },
  passengerModalInfo: {
    alignItems: 'center',
    padding: 20,
  },
  passengerModalAvatar: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: '#E8F5E9',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 15,
  },
  passengerModalInitial: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#008000',
  },
  passengerModalName: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#333333',
  },
  passengerModalDetails: {
    padding: 20,
    borderTopWidth: 1,
    borderTopColor: '#EEEEEE',
    borderBottomWidth: 1,
    borderBottomColor: '#EEEEEE',
  },
  passengerModalDetail: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 15,
  },
  passengerModalDetailLabel: {
    fontSize: 14,
    color: '#666666',
  },
  passengerModalDetailValue: {
    fontSize: 14,
    fontWeight: '500',
    color: '#333333',
  },
  modalFooter: {
    flexDirection: 'row',
    padding: 20,
  },
  closeModalButton: {
    flex: 1,
    backgroundColor: '#F5F5F5',
    borderRadius: 10,
    padding: 15,
    alignItems: 'center',
    marginRight: 10,
  },
  closeModalButtonText: {
    color: '#666666',
    fontSize: 16,
    fontWeight: '500',
  },
  checkInButton: {
    flex: 1,
    backgroundColor: '#008000',
    borderRadius: 10,
    padding: 15,
    alignItems: 'center',
  },
  checkInButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
});

export default TripDetailsScreen;