import React, { useEffect } from 'react';
import { View, StyleSheet, Image, Text, Animated, Easing } from 'react-native';
import { StatusBar } from 'expo-status-bar';

const SplashScreen = () => {
  // Animation values
  const logoOpacity = new Animated.Value(0);
  const logoScale = new Animated.Value(0.3);
  const textOpacity = new Animated.Value(0);
  
  useEffect(() => {
    // Start animations
    Animated.sequence([
      // Fade in and scale up logo
      Animated.parallel([
        Animated.timing(logoOpacity, {
          toValue: 1,
          duration: 800,
          useNativeDriver: true,
        }),
        Animated.timing(logoScale, {
          toValue: 1,
          duration: 800,
          easing: Easing.elastic(1.2),
          useNativeDriver: true,
        }),
      ]),
      // Fade in text after logo animation
      Animated.timing(textOpacity, {
        toValue: 1,
        duration: 600,
        delay: 200,
        useNativeDriver: true,
      }),
    ]).start();
  }, []);

  return (
    <View style={styles.container}>
      <StatusBar style="light" />
      
      {/* Logo Animation */}
      <Animated.View 
        style={[{
          opacity: logoOpacity,
          transform: [{ scale: logoScale }],
        }]}
      >
        <View style={styles.logoContainer}>
          <View style={styles.carBody}>
            <View style={styles.carTop} />
            <View style={styles.carBottom} />
            <View style={styles.carWindow} />
          </View>
          <View style={styles.wheel1} />
          <View style={styles.wheel2} />
        </View>
      </Animated.View>
      
      {/* Text Animation */}
      <Animated.View style={{ opacity: textOpacity }}>
        <Text style={styles.appName}>9jaRide</Text>
        <Text style={styles.tagline}>Connect. Ride. Arrive.</Text>
      </Animated.View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#008000',
    alignItems: 'center',
    justifyContent: 'center',
  },
  logoContainer: {
    width: 200,
    height: 120,
    marginBottom: 40,
    position: 'relative',
  },
  carBody: {
    width: 160,
    height: 60,
    backgroundColor: '#FFFFFF',
    borderRadius: 10,
    position: 'absolute',
    top: 30,
    left: 20,
  },
  carTop: {
    width: 100,
    height: 30,
    backgroundColor: '#FFFFFF',
    borderTopLeftRadius: 40,
    borderTopRightRadius: 40,
    position: 'absolute',
    top: -20,
    left: 30,
  },
  carWindow: {
    width: 80,
    height: 20,
    backgroundColor: '#008000',
    borderRadius: 5,
    position: 'absolute',
    top: 5,
    left: 40,
  },
  carBottom: {
    width: 180,
    height: 10,
    backgroundColor: '#FFFFFF',
    borderRadius: 5,
    position: 'absolute',
    bottom: -5,
    left: -10,
  },
  wheel1: {
    width: 30,
    height: 30,
    borderRadius: 15,
    backgroundColor: '#333333',
    position: 'absolute',
    bottom: 0,
    left: 30,
    borderWidth: 5,
    borderColor: '#666666',
  },
  wheel2: {
    width: 30,
    height: 30,
    borderRadius: 15,
    backgroundColor: '#333333',
    position: 'absolute',
    bottom: 0,
    right: 30,
    borderWidth: 5,
    borderColor: '#666666',
  },
  appName: {
    fontSize: 48,
    fontWeight: 'bold',
    color: '#FFFFFF',
    marginBottom: 10,
  },
  tagline: {
    fontSize: 18,
    color: '#FFFFFF',
    opacity: 0.9,
    textAlign: 'center',
  },
});

export default SplashScreen;