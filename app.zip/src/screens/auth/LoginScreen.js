import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Image,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  Alert,
} from 'react-native';
import { StatusBar } from 'expo-status-bar';
import AsyncStorage from '@react-native-async-storage/async-storage';

const LoginScreen = ({ navigation }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [userType, setUserType] = useState('passenger'); // 'passenger' or 'driver'

  const handleLogin = async () => {
    if (!email || !password) {
      Alert.alert('Error', 'Please fill in all fields');
      return;
    }

    setIsLoading(true);

    // Simulate API call
    setTimeout(async () => {
      setIsLoading(false);
      
      // For demo purposes, any login is successful
      // In a real app, you would validate credentials with your backend
      
      // Store user info
      await AsyncStorage.setItem('userToken', 'demo-token');
      await AsyncStorage.setItem('userType', userType);
      await AsyncStorage.setItem('userEmail', email);
      
      // Navigate to the appropriate screen based on user type
      if (userType === 'passenger') {
        navigation.replace('PassengerMain');
      } else {
        navigation.replace('DriverMain');
      }
    }, 1500);
  };

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      style={styles.container}
    >
      <StatusBar style="dark" />
      <ScrollView contentContainerStyle={styles.scrollContainer}>
        <View style={styles.logoContainer}>
          <View style={styles.carContainer}>
            <View style={styles.carBody}>
              <View style={styles.carTop} />
              <View style={styles.carWindow} />
            </View>
            <View style={styles.wheel1} />
            <View style={styles.wheel2} />
          </View>
          <Text style={styles.logoText}>9jaRide</Text>
        </View>

        <Text style={styles.welcomeText}>Welcome Back!</Text>
        <Text style={styles.subtitleText}>Sign in to continue</Text>

        <View style={styles.userTypeContainer}>
          <TouchableOpacity
            style={[styles.userTypeButton, userType === 'passenger' && styles.activeUserType]}
            onPress={() => setUserType('passenger')}
          >
            <Text style={[styles.userTypeText, userType === 'passenger' && styles.activeUserTypeText]}>Passenger</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.userTypeButton, userType === 'driver' && styles.activeUserType]}
            onPress={() => setUserType('driver')}
          >
            <Text style={[styles.userTypeText, userType === 'driver' && styles.activeUserTypeText]}>Driver</Text>
          </TouchableOpacity>
        </View>

        <View style={styles.inputContainer}>
          <Text style={styles.inputLabel}>Email</Text>
          <TextInput
            style={styles.input}
            placeholder="Enter your email"
            value={email}
            onChangeText={setEmail}
            keyboardType="email-address"
            autoCapitalize="none"
          />
        </View>

        <View style={styles.inputContainer}>
          <Text style={styles.inputLabel}>Password</Text>
          <TextInput
            style={styles.input}
            placeholder="Enter your password"
            value={password}
            onChangeText={setPassword}
            secureTextEntry
          />
        </View>

        <TouchableOpacity style={styles.forgotPasswordContainer}>
          <Text style={styles.forgotPasswordText}>Forgot Password?</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.loginButton}
          onPress={handleLogin}
          disabled={isLoading}
        >
          <Text style={styles.loginButtonText}>
            {isLoading ? 'Signing In...' : 'Sign In'}
          </Text>
        </TouchableOpacity>

        <View style={styles.registerContainer}>
          <Text style={styles.registerText}>Don't have an account? </Text>
          <TouchableOpacity onPress={() => navigation.navigate('Register')}>
            <Text style={styles.registerLink}>Sign Up</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFFFFF',
  },
  scrollContainer: {
    flexGrow: 1,
    padding: 20,
    paddingTop: 40,
  },
  logoContainer: {
    alignItems: 'center',
    marginBottom: 40,
  },
  carContainer: {
    width: 100,
    height: 60,
    position: 'relative',
    marginBottom: 10,
  },
  carBody: {
    width: 80,
    height: 30,
    backgroundColor: '#008000',
    borderRadius: 8,
    position: 'absolute',
    top: 15,
    left: 10,
  },
  carTop: {
    width: 50,
    height: 15,
    backgroundColor: '#008000',
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    position: 'absolute',
    top: -10,
    left: 15,
  },
  carWindow: {
    width: 40,
    height: 10,
    backgroundColor: '#FFFFFF',
    borderRadius: 3,
    position: 'absolute',
    top: 2,
    left: 20,
  },
  wheel1: {
    width: 15,
    height: 15,
    borderRadius: 7.5,
    backgroundColor: '#333333',
    position: 'absolute',
    bottom: 0,
    left: 15,
    borderWidth: 2,
    borderColor: '#666666',
  },
  wheel2: {
    width: 15,
    height: 15,
    borderRadius: 7.5,
    backgroundColor: '#333333',
    position: 'absolute',
    bottom: 0,
    right: 15,
    borderWidth: 2,
    borderColor: '#666666',
  },
  logoText: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#008000',
  },
  welcomeText: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#333333',
    marginBottom: 8,
  },
  subtitleText: {
    fontSize: 16,
    color: '#666666',
    marginBottom: 30,
  },
  userTypeContainer: {
    flexDirection: 'row',
    marginBottom: 20,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: '#DDDDDD',
    overflow: 'hidden',
  },
  userTypeButton: {
    flex: 1,
    paddingVertical: 12,
    alignItems: 'center',
  },
  activeUserType: {
    backgroundColor: '#008000',
  },
  userTypeText: {
    fontSize: 16,
    color: '#666666',
  },
  activeUserTypeText: {
    color: '#FFFFFF',
    fontWeight: 'bold',
  },
  inputContainer: {
    marginBottom: 20,
  },
  inputLabel: {
    fontSize: 14,
    color: '#666666',
    marginBottom: 8,
  },
  input: {
    borderWidth: 1,
    borderColor: '#DDDDDD',
    borderRadius: 10,
    padding: 15,
    fontSize: 16,
    backgroundColor: '#F9F9F9',
  },
  forgotPasswordContainer: {
    alignItems: 'flex-end',
    marginBottom: 30,
  },
  forgotPasswordText: {
    color: '#008000',
    fontSize: 14,
  },
  loginButton: {
    backgroundColor: '#008000',
    borderRadius: 10,
    padding: 18,
    alignItems: 'center',
    marginBottom: 20,
  },
  loginButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
  registerContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    marginTop: 10,
  },
  registerText: {
    color: '#666666',
    fontSize: 14,
  },
  registerLink: {
    color: '#008000',
    fontSize: 14,
    fontWeight: 'bold',
  },
});

export default LoginScreen;